package com.example.worldgymcenterapp.menu.perfil;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.metodos.correo.ObtenerDatosUser;
import com.example.worldgymcenterapp.metodos.correo.RecuperarDNI;
import com.example.worldgymcenterapp.metodos.correo.foto.GestorFotoPerfil;

public class AjustesCuenta extends AppCompatActivity {

    private ImageView profileImage;
    private TextView textViewNombre;
    private String dniUsuario = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perfil_ajustes_cuenta);

        // cargar y aplicar la imagen de perfil
        profileImage = findViewById(R.id.profile_image);
        GestorFotoPerfil.applyProfileImageToView(this, profileImage);

        // cargar el nombre del usuario
        textViewNombre = findViewById(R.id.textview_nombre);
        dniUsuario = RecuperarDNI.obtenerDni((this));
        ObtenerDatosUser.obtenerNombreCompleto(dniUsuario, new ObtenerDatosUser.ResultadoCallback() {
            @Override
            public void onResultadoObtenido(String resultado) {
                textViewNombre.setText(resultado);
            }
        });

        // configuracion el layout_titulo_perfil para retroceder a la ventana anterior
        LinearLayout layoutTituloPerfil = findViewById(R.id.layout_titulo_ajustes);
        layoutTituloPerfil.setOnClickListener(v -> onBackPressed());

        // configuracion layout_opcion_contrasena para abrir CambiarContrasenaActivity
        LinearLayout layoutOpcionContrasena = findViewById(R.id.layout_opcion_contrasena);
        layoutOpcionContrasena.setOnClickListener(v -> {
            Intent intent = new Intent(AjustesCuenta.this, AjustesCuentaCambiarContra.class);
            startActivity(intent);
        });

        // configuracion layout_opcion_eliminar_cuenta para abrir EliminarCuentaActivity
        LinearLayout layoutOpcionEliminarCuenta = findViewById(R.id.layout_opcion_eliminar_cuenta);
        layoutOpcionEliminarCuenta.setOnClickListener(v -> {
            Intent intent = new Intent(AjustesCuenta.this, AjustesCuentaEliminarCuenta.class);
            startActivity(intent);
        });
    }
}
