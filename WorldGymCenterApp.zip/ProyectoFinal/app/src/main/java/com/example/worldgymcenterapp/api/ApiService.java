package com.example.worldgymcenterapp.api;

import com.example.worldgymcenterapp.model.Calendario;
import com.example.worldgymcenterapp.model.Ejercicio;
import com.example.worldgymcenterapp.model.Cliente;
import com.example.worldgymcenterapp.model.Notificacion;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {

    // obtener la lista de todos los clientes
    @GET("/clientes")
    Call<List<Cliente>> obtenerClientes();

    // obtener un cliente por su dni
    @GET("/clientes/{dni}")
    Call<Cliente> obtenerClientePorDni(@Path("dni") String dni);

    // agregar un nuevo cliente
    @POST("/clientes")
    Call<Cliente> agregarCliente(@Body Cliente cliente);

    //@GET("clientes/verificar")
    // Call<Cliente> obtenerClientePorCorreoYContrasena(@Query("correo") String correo, @Query("contrasena") String contrasena);


    // obtener un cliente por correo y contraseña, devuelve dni si la autenticación es exitosa
    @GET("clientes/login/{email}/{contrasena}")
    Call<Cliente> obtenerClientePorCorreoYContrasena(
            @Path("email") String email,
            @Path("contrasena") String contrasena
    );

    // actualizar la información de un cliente por su dni
    @PUT("/clientes/{dni}")
    Call<String> actualizarCliente(@Path("dni") String dni, @Body Cliente cliente);

    // eliminar un cliente por su dni
    @DELETE("/clientes/{dni}")
    Call<String> eliminarCliente(@Path("dni") String dni);

    // actualizar la contraseña de un cliente
    @PUT("/clientes/{dni}/contrasena")
    Call<Cliente> actualizarContrasena(@Path("dni") String dni, @Body String nuevaContrasena);

    // actualizar el teléfono de un cliente
    @PUT("/clientes/{dni}/telefono")
    Call<Cliente> actualizarTelefono(@Path("dni") String dni, @Body String nuevoTelefono);

    // obtener la lista de clientes con pagos pendientes
    @GET("/clientes/pagos-pendientes")
    Call<List<Cliente>> obtenerClientesConPagosPendientes();

    // obtener la lista de todos los ejercicios
    @GET("/ejercicios")
    Call<List<Ejercicio>> obtenerTodosLosEjercicios();

    // obtener ejercicios por músculo
    @GET("/ejercicios/musculo/{musculo}")
    Call<List<Ejercicio>> obtenerEjerciciosPorMusculo(@Path("musculo") String musculo);

    // @POST("clientes/login/{email}/{contrasena}")
    // Call<String> login(@Path("email") String email, @Path("contrasena") String contrasena);

    // método para iniciar sesión, valida las credenciales de email y contraseña
    @POST("/clientes/login/{email}/{contrasena}")
    Call<String> login(@Path("email") String email, @Path("contrasena") String contrasena);

    // recuperar contraseña mediante dni y email
    @POST("clientes/recuperar-contrasena/{dni}/{email}")
    Call<String> recuperarContrasena(
            @Path("dni") String dni,
            @Path("email") String email
    );

    // cambiar la contraseña de un cliente
    @POST("clientes/cambiar-contrasena/{dni}/{contrasenaActual}/{nuevaContrasena}")
    Call<String> cambiarContrasena(
            @Path("dni") String dni,
            @Path("contrasenaActual") String contrasenaActual,
            @Path("nuevaContrasena") String nuevaContrasena
    );

    // obtener eventos del calendario por fecha
    @GET("/calendario/eventosPorFecha")
    Call<List<Calendario>> obtenerEventosPorFecha(@Query("fecha") String fecha);

    // obtener todos los eventos del calendario
    @GET("/calendario")
    Call<List<Calendario>> obtenerTodosLosEventos();

    // obtener las notificaciones ordenadas
    @GET("/notificaciones/ordenadas")
    Call<List<Notificacion>> obtenerNotificacionesOrdenadas();

    // comprobar si un ejercicio es favorito para un cliente
    @GET("/favoritos/es-favorito/{dni}/{ejercicioId}")
    Call<Boolean> esFavorito(@Path("dni") String dni, @Path("ejercicioId") int ejercicioId);

    // agregar un ejercicio a los favoritos de un cliente
    @POST("/favoritos/agregar/{dni}/{ejercicioId}")
    Call<Void> agregarFavorito(@Path("dni") String dni, @Path("ejercicioId") int ejercicioId);

    // eliminar un ejercicio de los favoritos de un cliente
    @DELETE("/favoritos/eliminar/{dni}/{ejercicioId}")
    Call<Void> eliminarFavorito(@Path("dni") String dni, @Path("ejercicioId") int ejercicioId);

    // obtener los ejercicios favoritos de un cliente
    @GET("favoritos/{dni}")
    Call<List<Ejercicio>> obtenerFavoritos(@Path("dni") String dni);

}
