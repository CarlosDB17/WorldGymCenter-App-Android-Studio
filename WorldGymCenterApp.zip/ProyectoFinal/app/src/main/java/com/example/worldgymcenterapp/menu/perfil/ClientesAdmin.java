package com.example.worldgymcenterapp.menu.perfil;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.api.ApiService;
import com.example.worldgymcenterapp.model.Cliente;
import com.example.worldgymcenterapp.api.RetrofitClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class ClientesAdmin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perfil_clientes);

        // obtener referencia al layout del título y poner acción de retroceso
        LinearLayout layoutTituloPerfil = findViewById(R.id.layout_titulo_clientes);
        layoutTituloPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();  // esto vuelve a la actividad anterior
            }
        });

        // obtener la instancia de retrofit desde retrofitclient
        Retrofit retrofit = RetrofitClient.getRetrofitInstance();
        ApiService apiService = retrofit.create(ApiService.class);

        // realizar una solicitud para obtener los clientes
        Call<List<Cliente>> call = apiService.obtenerClientes();
        call.enqueue(new Callback<List<Cliente>>() {
            @Override
            public void onResponse(Call<List<Cliente>> call, Response<List<Cliente>> response) {
                if (response.isSuccessful()) {
                    List<Cliente> clientes = response.body();  // obtener lista de clientes

                    // mostrar un mensaje con la cantidad de clientes obtenidos
                    Toast.makeText(ClientesAdmin.this, "Clientes obtenidos: " + clientes.size(), Toast.LENGTH_SHORT).show();
                } else {
                    // si la respuesta no es exitosa, mostrar un mensaje de error
                    Toast.makeText(ClientesAdmin.this, "Error al obtener clientes", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Cliente>> call, Throwable t) {
                // en caso de fallo en la conexión, mostrar un mensaje de error
                Toast.makeText(ClientesAdmin.this, "Error en la conexión: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                t.printStackTrace();  // esto imprime detalles del error en los logs
            }

        });
    }
}
