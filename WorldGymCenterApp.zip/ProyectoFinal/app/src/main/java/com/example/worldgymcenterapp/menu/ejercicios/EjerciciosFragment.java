package com.example.worldgymcenterapp.menu.ejercicios;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.worldgymcenterapp.R;
//import com.example.worldgymcenterapp.api.ApiClient;
import com.example.worldgymcenterapp.api.ApiService;
import com.example.worldgymcenterapp.adapters.EjercicioAdapter;
import com.example.worldgymcenterapp.metodos.correo.RecuperarDNI;
import com.example.worldgymcenterapp.model.Ejercicio;
import com.example.worldgymcenterapp.api.RetrofitClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class EjerciciosFragment extends Fragment {
    private RecyclerView recyclerView;
    private EjercicioAdapter adapter;
    private Spinner musculoSpinner;

    private boolean mostrandoFavoritos = false;
    private String usuarioDni = ""; // obtener el DNI del usuario actual

    private Button btnEjercicios,btnFavoritos;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //  el layout para este fragment
        View rootView = inflater.inflate(R.layout.fragment_ejercicios, container, false);

       usuarioDni = RecuperarDNI.obtenerDniSinContexto();


        // boton de ejercicios
        btnEjercicios = rootView.findViewById(R.id.btn_ejercicios);
        btnEjercicios.setOnClickListener(v -> {
            musculoSpinner.setVisibility(View.VISIBLE);
            mostrandoFavoritos = false;
            btnFavoritos.setTextColor(getResources().getColor(R.color.negroGym));
            btnEjercicios.setTextColor(getResources().getColor(R.color.BlancoNormalGym));
            btnEjercicios.setBackground(ContextCompat.getDrawable(requireContext(), R.drawable.boton_redondeado));
            btnFavoritos.setBackground(ContextCompat.getDrawable(requireContext(), R.drawable.boton_redondeado_no_seleccionado));
            obtenerTodosLosEjercicios();

            //btnFavoritos.setScaleX(0.80f);
            //btnEjercicios.setScaleX(1f);


        });

        // boton de favoritos
         btnFavoritos = rootView.findViewById(R.id.btn_favoritos);
        btnFavoritos.setOnClickListener(v -> {
            musculoSpinner.setVisibility(View.GONE);
            mostrandoFavoritos = true;
            btnFavoritos.setTextColor(getResources().getColor(R.color.BlancoNormalGym));
            btnEjercicios.setTextColor(getResources().getColor(R.color.negroGym));

           // btnFavoritos.setScaleX(1f);
           // btnEjercicios.setScaleX(0.80f);


            btnFavoritos.setBackground(ContextCompat.getDrawable(requireContext(), R.drawable.boton_redondeado));
            btnEjercicios.setBackground(ContextCompat.getDrawable(requireContext(), R.drawable.boton_redondeado_no_seleccionado));
            obtenerFavoritos();
        });



        // obtener el Spinner del layout
         musculoSpinner = rootView.findViewById(R.id.spinner_musculo);
        recyclerView = rootView.findViewById(R.id.recycler_view_ejercicios);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // creo un adaptador para el spinner con las opciones de músculos
        ArrayAdapter<CharSequence> musculosAdapter = ArrayAdapter.createFromResource(
                getContext(),
                R.array.musculos_array, // el array de strings que definiste en strings.xml
                android.R.layout.simple_spinner_item
        );
        musculosAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // spinner de musculos
        musculoSpinner.setAdapter(musculosAdapter);

        // establecer la opción predeterminada
        musculoSpinner.setSelection(0, false);  //ordenar por musculo por defecto

        // llamar a la API para obtener todos los ejercicios por defecto
        obtenerTodosLosEjercicios();

        // establecer el listener para cuando el usuario seleccione una opción
        musculoSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedMuscle = parentView.getItemAtPosition(position).toString();

                // Comprobar si el usuario ha seleccionado "Ordenar por músculo"
                if ("Ordenar por músculo".equals(selectedMuscle)) {
                    // Llamar al método para obtener todos los ejercicios si "Ordenar por músculo" es seleccionado
                    obtenerTodosLosEjercicios();
                   // Toast.makeText(getContext(), "Mostrando todos los ejercicios", Toast.LENGTH_SHORT).show();
                } else {
                    // Llamar a la API para obtener los ejercicios de ese músculo
                    obtenerEjerciciosPorMusculo(selectedMuscle);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {

            }
        });

        return rootView;
    }

    // metodo para obtener todos los ejercicios
    private void obtenerTodosLosEjercicios() {
        ApiService apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        Call<List<Ejercicio>> call = apiService.obtenerTodosLosEjercicios();

        call.enqueue(new Callback<List<Ejercicio>>() {
            @Override
            public void onResponse(Call<List<Ejercicio>> call, Response<List<Ejercicio>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    // actualizar el recyclerView con los ejercicios obtenidos
                    List<Ejercicio> ejercicios = response.body();
                    adapter = new EjercicioAdapter(ejercicios);
                    recyclerView.setAdapter(adapter);
                } else {
                    Toast.makeText(getContext(), "No se encontraron ejercicios", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Ejercicio>> call, Throwable t) {
                Toast.makeText(getContext(), "Error al cargar los ejercicios", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // metodo para obtener ejercicios por músculo
    private void obtenerEjerciciosPorMusculo(String musculo) {
        ApiService apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        Call<List<Ejercicio>> call = apiService.obtenerEjerciciosPorMusculo(musculo);

        call.enqueue(new Callback<List<Ejercicio>>() {
            @Override
            public void onResponse(Call<List<Ejercicio>> call, Response<List<Ejercicio>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    // actualizar el RecyclerView con los ejercicios obtenidos
                    List<Ejercicio> ejercicios = response.body();
                    adapter = new EjercicioAdapter(ejercicios);
                    recyclerView.setAdapter(adapter);
                } else {
                    Toast.makeText(getContext(), "No se encontraron ejercicios para este músculo", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Ejercicio>> call, Throwable t) {
                Toast.makeText(getContext(), "Error al cargar los ejercicios", Toast.LENGTH_SHORT).show();
            }
        });
    }


    // metodo para obtener favoritos
    private void obtenerFavoritos() {
        ApiService apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);
       Call<List<Ejercicio>> call = apiService.obtenerFavoritos(usuarioDni);


        call.enqueue(new Callback<List<Ejercicio>>() {
            @Override
            public void onResponse(Call<List<Ejercicio>> call, Response<List<Ejercicio>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Ejercicio> ejerciciosFavoritos = response.body();
                    adapter = new EjercicioAdapter(ejerciciosFavoritos, true); // nuevo parametro para marcar favoritos
                    recyclerView.setAdapter(adapter);
                } else {
                    Toast.makeText(getContext(), "No se encontraron ejercicios favoritos", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Ejercicio>> call, Throwable t) {
                Toast.makeText(getContext(), "Error al cargar los favoritos", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
