package com.example.worldgymcenterapp.model;

public class Pregunta {
    private String textoPregunta;  // texto de la pregunta
    private String respuestaTexto; // nuevo campo para la respuesta
    private int iconoResId;  // id del icono asociado a la pregunta
    private boolean respuestaVisible;  // indica si la respuesta es visible o no

    // constructor para inicializar la pregunta, respuesta y el icono
    public Pregunta(String textoPregunta, String respuestaTexto, int iconoResId) {
        this.textoPregunta = textoPregunta;
        this.respuestaTexto = respuestaTexto;
        this.iconoResId = iconoResId;
        this.respuestaVisible = false;  // la respuesta empieza oculta
    }

    // getter para obtener el texto de la pregunta
    public String getTextoPregunta() {
        return textoPregunta;
    }

    // setter para modificar el texto de la pregunta
    public void setTextoPregunta(String textoPregunta) {
        this.textoPregunta = textoPregunta;
    }

    // getter para obtener el texto de la respuesta
    public String getRespuestaTexto() {
        return respuestaTexto;
    }

    // setter para modificar el texto de la respuesta
    public void setRespuestaTexto(String respuestaTexto) {
        this.respuestaTexto = respuestaTexto;
    }

    // getter para obtener el id del icono
    public int getIconoResId() {
        return iconoResId;
    }

    // setter para modificar el id del icono
    public void setIconoResId(int iconoResId) {
        this.iconoResId = iconoResId;
    }

    // getter para saber si la respuesta es visible
    public boolean isRespuestaVisible() {
        return respuestaVisible;
    }

    // setter para modificar la visibilidad de la respuesta
    public void setRespuestaVisible(boolean respuestaVisible) {
        this.respuestaVisible = respuestaVisible;
    }
}
