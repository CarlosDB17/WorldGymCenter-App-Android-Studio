package com.example.worldgymcenterapp.notificaciones;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import androidx.core.app.NotificationCompat;

import com.example.worldgymcenterapp.R;

public class NotificacionHelper {

    public static void enviarNotificacionPrueba(Context context, String titulo, String mensaje) {
        // obtiene el servicio de notificacion
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // canal de notificacion (requiere en android O y versiones superiores)
        String channelId = "notificacion_prueba";
        String channelName = "Canal de Notificacion de Prueba";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(channel);
        }

        // construye la notificacion
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.logo_sin_letras) // asegurate de que este icono exista
                .setContentTitle(titulo)
                .setContentText(mensaje)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true); // la notificacion se cancela cuando se toca

        // envia la notificacion
        notificationManager.notify(1, builder.build());  // el ID '1' es un valor fijo, cambia si es necesario
    }
}
