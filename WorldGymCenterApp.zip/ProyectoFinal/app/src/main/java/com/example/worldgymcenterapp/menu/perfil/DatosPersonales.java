package com.example.worldgymcenterapp.menu.perfil;

import static com.example.worldgymcenterapp.metodos.correo.RecuperarDNI.obtenerDni;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.metodos.correo.foto.GestorFotoPerfil;
import com.example.worldgymcenterapp.api.ApiService;
import com.example.worldgymcenterapp.api.RetrofitClient;
import com.example.worldgymcenterapp.model.Cliente;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DatosPersonales extends AppCompatActivity {

    private static final int REQUEST_CODE_PICK_IMAGE = 1001;
    private ImageView profileImage;
    private SharedPreferences sharedPreferences;
    private String clienteDni = "";
    private EditText nombreEditText, apellidosEditText, correoEditText, telefonoEditText, dniEditText;
    private TextView nombreArriba;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perfil_datos_personales);

        // obtener las preferencias compartidas (shared preferences) del usuario
        sharedPreferences = getSharedPreferences("UserProfile", Context.MODE_PRIVATE);

        // inicializar los campos de edición de texto
        nombreEditText = findViewById(R.id.nombreEditText);
        apellidosEditText = findViewById(R.id.apellidosEditText);
        correoEditText = findViewById(R.id.correoEditText);
        telefonoEditText = findViewById(R.id.telefonoEditText);
        dniEditText = findViewById(R.id.dniEditText);
        profileImage = findViewById(R.id.profile_image);
        nombreArriba = findViewById(R.id.textview_nombre);
        Button guardarButton = findViewById(R.id.guardarButton);
        LinearLayout layoutTituloPerfil = findViewById(R.id.layout_titulo_perfil);

        // aplicar la imagen de perfil al ImageView
        GestorFotoPerfil.applyProfileImageToView(this, profileImage);

        // configurar el botón de guardar
        guardarButton.setOnClickListener(v -> {
            if (validateFields(nombreEditText, apellidosEditText, correoEditText, telefonoEditText)) {
                // si los campos son válidos, actualizar los datos del usuario
                actualizarDatosUsuario();
            }
        });

        // configurar el comportamiento del campo DNI
        dniEditText.setOnClickListener(v -> Toast.makeText(DatosPersonales.this, "El DNI no es posible modificarlo, es único para cada persona", Toast.LENGTH_SHORT).show());

        // configurar el comportamiento del título para volver a la actividad anterior
        layoutTituloPerfil.setOnClickListener(v -> onBackPressed());

        // configurar el comportamiento de la imagen de perfil
        profileImage.setOnClickListener(v -> openGallery());

        // obtener el DNI del cliente
        clienteDni = obtenerDni(this);
        cargarDatosDelUser(clienteDni);
    }

    // método para cargar los datos del cliente desde la API
    private void cargarDatosDelUser(String dni) {
        ApiService apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        Call<Cliente> call = apiService.obtenerClientePorDni(dni);

        call.enqueue(new Callback<Cliente>() {
            @Override
            public void onResponse(Call<Cliente> call, Response<Cliente> response) {
                if (response.isSuccessful() && response.body() != null) {
                    // si la respuesta es exitosa, cargar los datos del cliente en los campos
                    Cliente cliente = response.body();
                    nombreEditText.setText(cliente.getNombre());
                    apellidosEditText.setText(cliente.getApellidos());
                    correoEditText.setText(cliente.getEmail());
                    telefonoEditText.setText(cliente.getTelefono());
                    dniEditText.setText(cliente.getDni());
                    String nombreCompleto = cliente.getNombre() + " " + cliente.getApellidos();
                    nombreArriba.setText(nombreCompleto);

                } else {
                    Toast.makeText(DatosPersonales.this, "Error al obtener los datos del usuario", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Cliente> call, Throwable t) {
                Log.e("ErrorActualizador", "Error en la actualización del cliente: " + t.getMessage(), t);
                Toast.makeText(DatosPersonales.this, "Error de conexión: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }

        });
    }

    // método para actualizar los datos del usuario
    private void actualizarDatosUsuario() {
        String nuevoNombre = nombreEditText.getText().toString().trim();
        String nuevosApellidos = apellidosEditText.getText().toString().trim();
        String nuevoCorreo = correoEditText.getText().toString().trim();
        String nuevoTelefono = telefonoEditText.getText().toString().trim();

        Log.d("ActualizarUsuario", "Datos ingresados - Nombre: " + nuevoNombre +
                ", Apellidos: " + nuevosApellidos + ", Email: " + nuevoCorreo + ", Teléfono: " + nuevoTelefono);

        Cliente clienteActualizado = new Cliente(clienteDni, nuevoNombre, nuevosApellidos, nuevoCorreo, nuevoTelefono);

        ApiService apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        Call<String> call = apiService.actualizarCliente(clienteDni, clienteActualizado);

        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Log.i("ActualizarUsuario", "Cliente actualizado con éxito: " + response.body());
                    Toast.makeText(DatosPersonales.this, response.body(), Toast.LENGTH_SHORT).show();
                } else {
                    Log.w("ActualizarUsuario", "Error en la actualización - Código: " + response.code() +
                            ", Mensaje: " + response.message());
                    Toast.makeText(DatosPersonales.this, "Error al actualizar los datos: " + response.code(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                Log.e("ActualizarUsuario", "Error en la actualización del cliente: " + t.getMessage(), t);
                Toast.makeText(DatosPersonales.this, "Error de conexión: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // método para validar los campos de entrada
    private boolean validateFields(EditText... fields) {
        for (EditText field : fields) {
            if (field.getText().toString().trim().isEmpty()) {
                field.setError("Este campo es obligatorio");
                field.requestFocus();
                return false;
            }
        }
        return true;
    }

    // método para abrir la galería de imágenes
    private void openGallery() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, 200);
        } else {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, REQUEST_CODE_PICK_IMAGE);
        }
    }

    // manejar el resultado de la selección de una imagen en la galería
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri selectedImageUri = data.getData();
            if (selectedImageUri != null) {
                profileImage.setImageURI(selectedImageUri);
                GestorFotoPerfil.saveProfileImage(this, selectedImageUri);
            }
        }
    }
}
