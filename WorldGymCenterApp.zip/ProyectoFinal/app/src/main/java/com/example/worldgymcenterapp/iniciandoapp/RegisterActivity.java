package com.example.worldgymcenterapp.iniciandoapp;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.api.ApiService;
import com.example.worldgymcenterapp.api.RetrofitClient;
import com.example.worldgymcenterapp.metodos.correo.ComprobarDNI;
import com.example.worldgymcenterapp.model.Cliente;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {
    // declaramos los campos de entrada del formulario para el registro
    private EditText nombreEditText, apellidosEditText, dniEditText, correoEditText, contrasenaEditText, telefonoEditText;
    private TextView fechaNacimientoTextView;  // campo para mostrar la fecha de nacimiento seleccionada
    private Button registerButton;  // botón para iniciar el registro
    private ApiService apiService;  // interfaz que conecta con la API
    private ScrollView scrollRegister;  // vista deslizante para el formulario
    private android.widget.ProgressBar progressBar;  // barra de progreso que indica que el registro está en curso

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);  // el layout de registro

        // inicializamos los campos de entrada con sus respectivos IDs en el layout
        nombreEditText = findViewById(R.id.nombreEditText);
        apellidosEditText = findViewById(R.id.apellidosEditText);
        dniEditText = findViewById(R.id.dniEditText);
        correoEditText = findViewById(R.id.correoEditText);
        contrasenaEditText = findViewById(R.id.contrasenaEditText);
        telefonoEditText = findViewById(R.id.telefonoEditText);
        fechaNacimientoTextView = findViewById(R.id.fechaNacimientoTextView);
        registerButton = findViewById(R.id.registerButton);

        // inicializamos los otros elementos de la vista como el ScrollView y ProgressBar
        scrollRegister = findViewById(R.id.scrollRegister);
        progressBar = findViewById(R.id.progressBar);

        // obtenemos la instancia de la API mediante Retrofit
        apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);

        // evento para abrir el selector de fecha al hacer clic en el campo de fecha de nacimiento
        fechaNacimientoTextView.setOnClickListener(view -> mostrarDatePicker());

        // evento para validar el registro cuando se pulsa el botón de registro
        registerButton.setOnClickListener(view -> validarRegistro());
    }

    // método para mostrar el selector de fecha (DatePickerDialog)
    private void mostrarDatePicker() {
        Calendar calendar = Calendar.getInstance();  // obtenemos la fecha actual
        int anio = calendar.get(Calendar.YEAR);
        int mes = calendar.get(Calendar.MONTH);
        int dia = calendar.get(Calendar.DAY_OF_MONTH);

        // creamos el selector de fecha
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            // se configura la fecha seleccionada por el usuario
            Calendar fechaSeleccionada = Calendar.getInstance();
            fechaSeleccionada.set(year, month, dayOfMonth);

            // validamos que la fecha no sea futura
            if (fechaSeleccionada.after(calendar)) {
                Toast.makeText(this, "no puedes seleccionar una fecha futura", Toast.LENGTH_SHORT).show();
            } else {
                // convertimos la fecha seleccionada a formato Date
                Date selectedDate = fechaSeleccionada.getTime();

                // formateamos la fecha a "dd-MM-yyyy"
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String fechaNacimientoFormateada = sdf.format(selectedDate);

                // mostramos la fecha seleccionada en el TextView
                fechaNacimientoTextView.setText(fechaNacimientoFormateada);
                fechaNacimientoTextView.setTextColor(ContextCompat.getColor(this, R.color.grisGym));

                // registramos en log la fecha seleccionada
                Log.d("registro", "fecha de nacimiento seleccionada: " + fechaNacimientoFormateada);
            }
        }, anio, mes, dia);

        // mostramos el selector de fecha
        datePickerDialog.show();
    }

    // método para validar los datos del formulario
    private void validarRegistro() {
        // obtenemos los valores ingresados en el formulario
        String nombre = nombreEditText.getText().toString().trim();
        String apellidos = apellidosEditText.getText().toString().trim();
        String dni = dniEditText.getText().toString().trim();
        String correo = correoEditText.getText().toString().trim();
        String contrasena = contrasenaEditText.getText().toString().trim();
        String telefono = telefonoEditText.getText().toString().trim();
        String fechaNacimiento = fechaNacimientoTextView.getText().toString().trim();

        // registramos los datos para depuración
        Log.d("registro", "validando datos...");
        Log.d("registro", "nombre: " + nombre);
        Log.d("registro", "apellidos: " + apellidos);
        Log.d("registro", "dni: " + dni);
        Log.d("registro", "correo: " + correo);
        Log.d("registro", "contraseña: " + contrasena);
        Log.d("registro", "teléfono: " + telefono);
        Log.d("registro", "fecha de nacimiento: " + fechaNacimiento);

        // validamos que todos los campos estén llenos
        if (nombre.isEmpty() || apellidos.isEmpty() || dni.isEmpty() || correo.isEmpty() || contrasena.isEmpty() || telefono.isEmpty() || fechaNacimiento.isEmpty()) {
            Toast.makeText(this, "todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
            Log.e("registro", "error: campos vacíos.");
            return;
        }

        // validamos que el DNI sea correcto
        if (!ComprobarDNI.validarDNI(dni)) {
            Toast.makeText(this, "dni no válido", Toast.LENGTH_SHORT).show();
            Log.e("registro", "error: dni no válido.");
            return;
        }

        // validamos que el correo tenga el formato adecuado
        if (!correo.contains("@")) {
            Toast.makeText(this, "correo electrónico inválido", Toast.LENGTH_SHORT).show();
            Log.e("registro", "error: formato de correo inválido.");
            return;
        }

        // mostramos el ProgressBar y ocultamos el ScrollView mientras se realiza el registro
        scrollRegister.setVisibility(android.view.View.GONE);
        progressBar.setVisibility(android.view.View.VISIBLE);

        // creamos un objeto Cliente con los datos ingresados
        Cliente nuevoCliente = new Cliente(dni, nombre, apellidos, correo, contrasena, telefono, fechaNacimiento);
        Log.d("registro", "cliente creado: " + nuevoCliente);

        // realizamos la llamada a la API para agregar el nuevo cliente
        Call<Cliente> call = apiService.agregarCliente(nuevoCliente);
        call.enqueue(new Callback<Cliente>() {
            @Override
            public void onResponse(Call<Cliente> call, Response<Cliente> response) {
                // ocultamos el ProgressBar y mostramos el ScrollView nuevamente
                progressBar.setVisibility(android.view.View.GONE);
                scrollRegister.setVisibility(android.view.View.VISIBLE);

                // si la respuesta es exitosa, mostramos un mensaje y cerramos la actividad
                if (response.isSuccessful()) {
                    Log.d("registro", "registro exitoso: " + response.body());
                    Toast.makeText(RegisterActivity.this, "registro completado", Toast.LENGTH_SHORT).show();
                    finish();  // cerramos la actividad
                } else {
                    // si ocurre un error en el registro, mostramos el código de error
                    Log.e("registro", "error en el registro: " + response.code());
                    try {
                        String errorBody = response.errorBody().string();
                        Log.e("registro", "detalles del error: " + errorBody);

                        // extraemos el mensaje de error y lo mostramos
                        String mensajeError = errorBody.substring(errorBody.indexOf(":") + 2, errorBody.length() - 2);

                        Toast.makeText(RegisterActivity.this, mensajeError, Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        // si ocurre un error al procesar el mensaje de error, mostramos un mensaje genérico
                        Log.e("registro", "no se pudo obtener detalles del error.", e);
                        Toast.makeText(RegisterActivity.this, "error en el registro", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<Cliente> call, Throwable t) {
                // ocultamos el ProgressBar y mostramos el ScrollView nuevamente
                progressBar.setVisibility(android.view.View.GONE);
                scrollRegister.setVisibility(android.view.View.VISIBLE);

                // si falla la conexión, mostramos un mensaje de error
                Log.e("registro", "error de conexión", t);
                Toast.makeText(RegisterActivity.this, "error de conexión", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
