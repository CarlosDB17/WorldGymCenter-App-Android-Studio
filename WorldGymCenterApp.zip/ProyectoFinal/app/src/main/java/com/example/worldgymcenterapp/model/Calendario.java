package com.example.worldgymcenterapp.model;

public class Calendario {

    private Long id;  // identificador unico para cada evento en el calendario
    private String titulo;  // titulo del evento
    private String descripcion;  // descripcion detallada del evento
    private String tipo;  // tipo de evento (por ejemplo: yoga, boxeo, etc.)
    private String fecha;  // fecha y hora del evento (almacenada como texto)
    private String duracion;  // duracion del evento (como texto, por ejemplo 60 min)
    private String url;  // enlace a una imagen

    // constructor vacio para inicializar el objeto sin parametros
    public Calendario() {
    }

    // constructor con parametros para crear un objeto Calendario con los valores proporcionados
    public Calendario(Long id, String titulo, String descripcion, String tipo, String fecha, String duracion, String url) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.tipo = tipo;
        this.fecha = fecha;
        this.duracion = duracion;
        this.url = url;
    }

    // getters y setters para acceder y modificar los valores de los atributos

    public Long getId() {
        return id;  // devuelve el id del evento
    }

    public void setId(Long id) {
        this.id = id;  // establece el id del evento
    }

    public String getTitulo() {
        return titulo;  // devuelve el titulo del evento
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;  // establece el titulo del evento
    }

    public String getDescripcion() {
        return descripcion;  // devuelve la descripcion del evento
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;  // establece la descripcion del evento
    }

    public String getTipo() {
        return tipo;  // devuelve el tipo del evento
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;  // establece el tipo del evento
    }

    public String getFecha() {
        return fecha;  // devuelve la fecha y hora del evento
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;  // establece la fecha y hora del evento
    }

    public String getDuracion() {
        return duracion;  // devuelve la duracion del evento
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;  // establece la duracion del evento
    }

    public String getUrl() {
        return url;  // devuelve la URL asociada al evento
    }

    public void setUrl(String url) {
        this.url = url;  // establece la URL asociada al evento
    }
}
