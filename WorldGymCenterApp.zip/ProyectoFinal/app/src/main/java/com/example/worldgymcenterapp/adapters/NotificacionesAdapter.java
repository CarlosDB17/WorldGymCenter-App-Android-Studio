package com.example.worldgymcenterapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.model.Notificacion;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class NotificacionesAdapter extends RecyclerView.Adapter<NotificacionesAdapter.NotificacionViewHolder> {
    private List<Notificacion> listaNotificaciones;
    private Context context;
    private OnItemClickListener listener;


    public interface OnItemClickListener {
        void onItemClick(Notificacion notificacion);
    }

    public NotificacionesAdapter(List<Notificacion> listaNotificaciones, Context context, OnItemClickListener listener) {
        this.listaNotificaciones = listaNotificaciones;
        this.context = context;
        this.listener = listener;
    }

    @NonNull
    @Override
    public NotificacionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_notificacion, parent, false);
        return new NotificacionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NotificacionViewHolder holder, int position) {
        Notificacion notificacion = listaNotificaciones.get(position);

        holder.tvTitulo.setText(notificacion.getTitulo());
        holder.tvDescripcion.setText(notificacion.getDescripcion());

        // formatear fecha
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
        holder.tvFecha.setText(sdf.format(notificacion.getFecha()));

        // image desde url
        if (notificacion.getUrlFoto() != null && !notificacion.getUrlFoto().isEmpty()) {
            holder.ivImagen.setVisibility(View.VISIBLE);
            Glide.with(context)
                    .load(notificacion.getUrlFoto())
                    .transition(DrawableTransitionOptions.withCrossFade())
                    .error(R.drawable.ic_notificacion) // Imagen de error si la carga falla
                    .into(holder.ivImagen);

            // poner de color rojo
            holder.ivImagen.setColorFilter(context.getResources().getColor(R.color.rojoNormalGym), android.graphics.PorterDuff.Mode.MULTIPLY);
        } else {
            holder.ivImagen.setVisibility(View.VISIBLE);
            holder.ivImagen.setImageResource(R.drawable.ic_notificacion); // Imagen por defecto
            holder.ivImagen.setBackgroundColor(context.getResources().getColor(R.color.rojoNormalGym)); // Fondo rojoNormalGym
        }


        holder.itemView.setOnClickListener(v -> listener.onItemClick(notificacion));
    }

    @Override
    public int getItemCount() {
        return listaNotificaciones != null ? listaNotificaciones.size() : 0;
    }


    public void setNotificaciones(List<Notificacion> notificaciones) {
        this.listaNotificaciones = notificaciones;
        notifyDataSetChanged();
    }

    static class NotificacionViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitulo, tvDescripcion, tvFecha;
        ImageView ivImagen;

        public NotificacionViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitulo = itemView.findViewById(R.id.titulo_notificacion);
            tvDescripcion = itemView.findViewById(R.id.descripcion_notificacion);
            tvFecha = itemView.findViewById(R.id.fecha_notificacion);
            ivImagen = itemView.findViewById(R.id.imagen_notificacion);
        }
    }
}