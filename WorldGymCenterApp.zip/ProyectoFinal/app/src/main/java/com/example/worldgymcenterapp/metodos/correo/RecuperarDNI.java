package com.example.worldgymcenterapp.metodos.correo;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

public class RecuperarDNI {

    private static final String PREF_NAME = "UserPrefs"; // nombre del archivo de sharedpreferences
    private static final String KEY_DNI = "dni_encrypted"; // clave para almacenar el dni cifrado
    private static Context appContext; // contexto de la app

    // inicializar la clase con el contexto de la aplicacion (se recomienda llamar en MainActivity o Application)
    public static void init(Context context) {
        if (appContext == null) {
            appContext = context.getApplicationContext(); // guarda el contexto de la aplicacion
        }
    }

    // guardar dni cifrado en sharedpreferences
    public static void guardarDni(Context context, String dni) {
        // cifra el dni usando Base64
        String encryptedDni = Base64.encodeToString(dni.getBytes(), Base64.DEFAULT);
        // obtener sharedpreferences en modo privado
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        // almacenar el dni cifrado
        sharedPreferences.edit().putString(KEY_DNI, encryptedDni).apply();
    }

    // recuperar dni descifrado desde sharedpreferences (requiere contexto)
    public static String obtenerDni(Context context) {
        // obtener sharedpreferences en modo privado
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        // obtener el dni cifrado de las sharedpreferences
        String encryptedDni = sharedPreferences.getString(KEY_DNI, null);

        if (encryptedDni != null) {
            // descifra el dni usando Base64
            byte[] decodedBytes = Base64.decode(encryptedDni, Base64.DEFAULT);
            return new String(decodedBytes); // devuelve el dni descifrado
        }
        return null; // si no hay un dni almacenado, devuelve null
    }

    // nuevo metodo: recuperar dni sin necesidad de pasar contexto
    public static String obtenerDniSinContexto() {
        // verifica si el contexto no ha sido inicializado
        if (appContext == null) {
            throw new IllegalStateException("RecuperarDNI no ha sido inicializado. Llama a init(Context) en MainActivity o Application.");
        }
        return obtenerDni(appContext); // llama al metodo obtenerDni con el contexto global
    }

    // borrar dni de sharedpreferences
    public static void borrarDni(Context context) {
        // obtener sharedpreferences en modo privado
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        // eliminar el dni almacenado
        sharedPreferences.edit().remove(KEY_DNI).apply();
    }
}
