package com.example.worldgymcenterapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.example.worldgymcenterapp.iniciandoapp.Bienvenida;
import com.example.worldgymcenterapp.login.Login;
import com.example.worldgymcenterapp.metodos.correo.RecuperarDNI;

import java.io.IOException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.iniciando_app);
        // inicializar la clase RecuperarDNI con el contexto de la aplicacion
        RecuperarDNI.init(this);

        ImageView imageView = findViewById(R.id.fotoInicio);
        Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        imageView.startAnimation(fadeIn);
        imageView.setVisibility(ImageView.VISIBLE);

        // esperar 3 segundos antes de redirigir
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            // comprobar si la API esta funcionando
            comprobarEstadoAPI();
        }, 3000);
    }

    private void comprobarEstadoAPI() {
        // utiliza OkHttp para hacer la peticion a la API
        OkHttpClient client = new OkHttpClient();

        //   endpoint de notificaciones para verificar si la API esta activa
        String url = "http://87.218.236.11:8080/notificaciones";

        Request request = new Request.Builder()
                .url(url)
                .build();

        // ejecuta la peticion en un hilo separado
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                Response response = client.newCall(request).execute();

                // procesa la respuesta en el hilo principal
                new Handler(Looper.getMainLooper()).post(() -> {
                    if (response.isSuccessful()) {
                        // API funcionando, continuar con el flujo normal
                        continuarFlujoNormal();
                    } else {
                        // API no funcionando, redirigir a AppNoOperativa
                        startActivity(new Intent(MainActivity.this, AppNoOperativa.class));
                        finish();
                    }
                });
            } catch (IOException e) {
                // error de conexion, la API no esta disponible
                new Handler(Looper.getMainLooper()).post(() -> {
                    startActivity(new Intent(MainActivity.this, AppNoOperativa.class));
                    finish();
                });
            }
        });
    }

    private void continuarFlujoNormal() {
        if (verificarAutenticacion()) {
            startActivity(new Intent(MainActivity.this, MainScreenActivity.class));
        } else {
            startActivity(new Intent(MainActivity.this, Bienvenida.class));
        }
        finish();
    }

    // comprueba si hay sesion iniciada en SharedPreferences
    private boolean verificarAutenticacion() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        return sharedPreferences.contains("dni_encrypted"); // si existe, ya esta autenticado
    }
}
