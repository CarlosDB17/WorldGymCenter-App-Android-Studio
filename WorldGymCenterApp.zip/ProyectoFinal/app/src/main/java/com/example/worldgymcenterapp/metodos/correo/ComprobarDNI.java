package com.example.worldgymcenterapp.metodos.correo;

public class ComprobarDNI {

    // metodo para validar el dni
    public static boolean validarDNI(String dni) {
        // se verifica que el dni no sea nulo y que tenga el formato correcto (8 digitos seguidos de una letra)
        if (dni == null || !dni.matches("\\d{8}[a-hj-np-tv-zA-HJ-NP-TV-Z]")) {
            return false;
        }

        // las letras asociadas al numero del dni
        String letras = "TRWAGMYFPDXBNJZSQVHLCKE";
        // se extrae el numero del dni
        int numero = Integer.parseInt(dni.substring(0, 8));
        // se calcula la letra correcta a partir del numero
        char letraCorrecta = letras.charAt(numero % 23);
        // se obtiene la letra proporcionada por el usuario, convirtiendola a mayusculas
        char letraUsuario = Character.toUpperCase(dni.charAt(8)); // convertir a mayuscula

        // se devuelve true si la letra proporcionada por el usuario coincide con la letra calculada
        return letraCorrecta == letraUsuario;
    }
}
