package com.example.worldgymcenterapp.model;

import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Notificacion {
    @SerializedName("id")
    private Integer id;  // id unico de la notificacion

    @SerializedName("titulo")
    private String titulo;  // titulo de la notificacion

    @SerializedName("descripcion")
    private String descripcion;  // descripcion de la notificacion

    @SerializedName("urlFoto")
    private String urlFoto;  // url de la foto asociada a la notificacion

    @SerializedName("fecha")
    @JsonAdapter(CustomDateAdapter.class)  // adaptador personalizado para manejar la fecha
    private Date fecha;  // fecha y hora de la notificacion

    // constructor vacio
    public Notificacion() {}

    // getters y setters

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUrlFoto() {
        return urlFoto;
    }

    public void setUrlFoto(String urlFoto) {
        this.urlFoto = urlFoto;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    // adaptador personalizado para manejar las fechas
    public static class CustomDateAdapter extends TypeAdapter<Date> {
        private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault());

        // metodo para escribir la fecha en el formato adecuado
        @Override
        public void write(JsonWriter out, Date value) throws IOException {
            if (value == null) {
                out.nullValue();  // si la fecha es nula, se escribe nulo
            } else {
                out.value(dateFormat.format(value));  // escribe la fecha formateada
            }
        }

        // metodo para leer la fecha desde el formato adecuado
        @Override
        public Date read(JsonReader in) throws IOException {
            try {
                return dateFormat.parse(in.nextString());  // parsea la fecha del string
            } catch (ParseException e) {
                throw new IOException("Error parsing date", e);  // maneja el error si el formato es incorrecto
            }
        }
    }
}
