package com.example.worldgymcenterapp.menu.perfil;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.login.Login;
import com.example.worldgymcenterapp.metodos.correo.RecuperarDNI;

public class CerrarSesion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perfil_cerrar_sesion);

        // botones
        Button btnSi = findViewById(R.id.btn_si);
        Button btnNo = findViewById(R.id.btn_no);
        LinearLayout layoutTituloCerrarSesion = findViewById(R.id.layout_titulo_cerrar_sesion);

        // accion al presionar "si" (cerrar sesion)
        btnSi.setOnClickListener(view -> {
            // borrar el dni encriptado usando el metodo de RecuperarDNI
            RecuperarDNI.borrarDni(this);

            Toast.makeText(CerrarSesion.this, "Sesion cerrada", Toast.LENGTH_SHORT).show();

            // ir a la pantalla de login y limpiar la pila de actividades
            Intent intent = new Intent(CerrarSesion.this, Login.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        // accion al presionar "no" (volver atras)
        btnNo.setOnClickListener(view -> finish());

        // accion al presionar el titulo (volver atras)
        layoutTituloCerrarSesion.setOnClickListener(v -> onBackPressed());
    }
}
