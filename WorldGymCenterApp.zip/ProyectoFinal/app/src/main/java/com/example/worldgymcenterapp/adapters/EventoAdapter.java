package com.example.worldgymcenterapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.model.Calendario;

import java.util.List;

public class EventoAdapter extends RecyclerView.Adapter<EventoAdapter.EventoViewHolder> {

    private Context context;
    private List<Calendario> eventos;

    public EventoAdapter(Context context, List<Calendario> eventos) {
        this.context = context;
        this.eventos = eventos;
    }

    @NonNull
    @Override
    public EventoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.item_evento, parent, false);
        return new EventoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventoViewHolder holder, int position) {
        Calendario evento = eventos.get(position);

        // establecer los valores de los atributos de evento en el layout
        holder.tituloEvento.setText(evento.getTitulo());
        holder.descripcionEvento.setText(evento.getDescripcion());

        // usar la fecha como texto
        holder.fechaEvento.setText(evento.getFecha());

        // duración
        holder.duracionEvento.setText("Duración: " + evento.getDuracion());

    }

    @Override
    public int getItemCount() {
        return eventos.size();
    }

    public static class EventoViewHolder extends RecyclerView.ViewHolder {

        TextView tituloEvento, descripcionEvento, fechaEvento, duracionEvento;
        ImageView iconoCategoria;

        public EventoViewHolder(View itemView) {
            super(itemView);

            // inicializar las vistas del layout
            tituloEvento = itemView.findViewById(R.id.titulo_evento);
            descripcionEvento = itemView.findViewById(R.id.descripcion_evento);
            fechaEvento = itemView.findViewById(R.id.fecha_evento);
            duracionEvento = itemView.findViewById(R.id.duracion_evento);
            iconoCategoria = itemView.findViewById(R.id.icono_categoria_evento);
        }
    }
}
