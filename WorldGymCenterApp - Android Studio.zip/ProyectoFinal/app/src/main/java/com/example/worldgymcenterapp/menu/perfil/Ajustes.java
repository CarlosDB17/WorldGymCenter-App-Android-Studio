package com.example.worldgymcenterapp.menu.perfil;

import static com.example.worldgymcenterapp.metodos.correo.RecuperarDNI.obtenerDni;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.metodos.correo.ObtenerDatosUser;
import com.example.worldgymcenterapp.metodos.correo.foto.GestorFotoPerfil;

public class Ajustes extends AppCompatActivity {

    private ImageView profileImage;
    private TextView nombreArriba;
    private String clienteDni = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perfil_ajustes);

        nombreArriba = findViewById(R.id.textview_nombre);
        clienteDni = obtenerDni(this);

        // obtener y establecer el nombre del usuario
        ObtenerDatosUser.obtenerNombreCompleto(clienteDni, resultado -> {
            if (resultado != null && !resultado.isEmpty()) {
                nombreArriba.setText(resultado);
            } else {
                nombreArriba.setText("Nombre no disponible");
            }
        });

        // cargar y aplicar la imagen de perfil
        profileImage = findViewById(R.id.profile_image);
        GestorFotoPerfil.applyProfileImageToView(this, profileImage);

        // configura el layout_titulo_perfil para retroceder a la ventana anterior
        LinearLayout layoutTituloPerfil = findViewById(R.id.layout_titulo_ajustes);
        layoutTituloPerfil.setOnClickListener(v -> onBackPressed());

        // configuración de botones
        LinearLayout layoutOpcionNotificaciones = findViewById(R.id.layout_opcion_notificaciones);
        layoutOpcionNotificaciones.setOnClickListener(v -> {
            Intent intent = new Intent(Ajustes.this, AjustesNotificaciones.class);
            startActivity(intent);
        });

        LinearLayout layoutOpcionCuenta = findViewById(R.id.layout_opcion_ajustes_cuenta);
        layoutOpcionCuenta.setOnClickListener(v -> {
            Intent intent = new Intent(Ajustes.this, AjustesCuenta.class);
            startActivity(intent);
        });
    }

}
