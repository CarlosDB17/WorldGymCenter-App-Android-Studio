package com.example.worldgymcenterapp.menu.calendario;

import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.applandeo.materialcalendarview.CalendarView;
import com.applandeo.materialcalendarview.EventDay;
import com.applandeo.materialcalendarview.listeners.OnDayClickListener;
import com.bumptech.glide.Glide;
import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.api.ApiService;
import com.example.worldgymcenterapp.api.RetrofitClient;
import com.example.worldgymcenterapp.model.Calendario;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CalendarFragment extends Fragment {

    private CalendarView calendarView;
    private LinearLayout eventosContainer;
    private List<EventDay> eventosMarcados = new ArrayList<>(); // lista para almacenar los eventos marcados
    private Calendar selectedCalendar = Calendar.getInstance(); // calendario para la fecha seleccionada

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_calendario, container, false);

        // inicializamos el calendario
        calendarView = view.findViewById(R.id.calendarView);
        eventosContainer = view.findViewById(R.id.eventosContainer);

        // primero, cargar todos los eventos para marcar el calendario
        cargarTodosLosEventos();

        // configurar el listener para fechas seleccionadas
        calendarView.setOnDayClickListener(new OnDayClickListener() {
            @Override
            public void onDayClick(EventDay eventDay) {
                // obtener la fecha seleccionada
                selectedCalendar = eventDay.getCalendar();

                // llamar al metodo para marcarla en rojo
                marcarFechaSeleccionada(selectedCalendar);

                // formatear la fecha antes de enviarla a la API
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                String fechaFormateada = sdf.format(selectedCalendar.getTime());
                Log.d("Calendario", "Fecha seleccionada: " + fechaFormateada);

                // obtener eventos para la fecha seleccionada
                obtenerEventos(fechaFormateada);
            }
        });



        // llamar a la API para mostrar los eventos de hoy al entrar al fragmento
        obtenerEventosDeHoy();

        return view;
    }




    private void cargarTodosLosEventos() {
        Log.d("Calendario", "Cargando todos los eventos para marcar el calendario");
        ApiService apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        Call<List<Calendario>> call = apiService.obtenerTodosLosEventos();
        call.enqueue(new Callback<List<Calendario>>() {
            @Override
            public void onResponse(Call<List<Calendario>> call, Response<List<Calendario>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Calendario> todosLosEventos = response.body();
                    Log.d("Calendario", "Total de eventos obtenidos: " + todosLosEventos.size());
                    marcarDiasConEventos(todosLosEventos);
                } else {
                    Log.d("Calendario", "Error al obtener todos los eventos: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<List<Calendario>> call, Throwable t) {
                Log.e("Calendario", "Error en la conexion al cargar todos los eventos: " + t.getMessage());
            }
        });
    }

    private void marcarDiasConEventos(List<Calendario> eventos) {
        eventosMarcados.clear();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

        // usamos un mapa para agrupar eventos por fecha y evitar duplicados
        Map<String, Calendar> fechasConEventos = new HashMap<>();

        for (Calendario evento : eventos) {
            try {
                // asumiendo que cada evento tiene una propiedad "fecha" en formato "yyyy-MM-dd"
                String fechaEvento = evento.getFecha();

                // si ya tenemos un evento para esta fecha, continuamos al siguiente
                if (fechasConEventos.containsKey(fechaEvento)) {
                    continue;
                }

                Date date = sdf.parse(fechaEvento);
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(date);

                // guardamos esta fecha en nuestro mapa
                fechasConEventos.put(fechaEvento, calendar);

                // creamos un EventDay para esta fecha con un icono
                EventDay eventDay = new EventDay(calendar, R.drawable.ic_event_available);
                eventosMarcados.add(eventDay);

                Log.d("Calendario", "Marcando evento para el dia: " + fechaEvento);
            } catch (ParseException e) {
                Log.e("Calendario", "Error al parsear la fecha: " + e.getMessage());
            }
        }

        // aplicar los eventos al calendario
        if (!eventosMarcados.isEmpty()) {
            calendarView.setEvents(eventosMarcados);
            Log.d("Calendario", "Total de dias marcados con eventos: " + eventosMarcados.size());
        }
    }

    private void obtenerEventosDeHoy() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        String fechaHoy = sdf.format(System.currentTimeMillis());
        obtenerEventos(fechaHoy);
    }

    private void obtenerEventos(String fechaSeleccionada) {
        Log.d("Calendario", "Realizando llamada a la API con fecha: " + fechaSeleccionada);

        ApiService apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        Call<List<Calendario>> call = apiService.obtenerEventosPorFecha(fechaSeleccionada);

        call.enqueue(new Callback<List<Calendario>>() {
            @Override
            public void onResponse(Call<List<Calendario>> call, Response<List<Calendario>> response) {
                Log.d("Calendario", "Respuesta de la API recibida. Codigo de estado: " + response.code());

                if (response.isSuccessful() && response.body() != null) {
                    List<Calendario> eventosDelDia = response.body();
                    Log.d("Calendario", "Eventos encontrados: " + eventosDelDia.size());
                    mostrarEventos(eventosDelDia);
                } else {
                    Log.d("Calendario", "No se encontraron eventos.");
                    mostrarEventos(new ArrayList<>()); // mostrar mensaje de que no hay eventos
                }
            }

            @Override
            public void onFailure(Call<List<Calendario>> call, Throwable t) {
                Log.e("Calendario", "Error en la conexion: " + t.getMessage());
                Toast.makeText(getActivity(), "Error en la conexion: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void mostrarEventos(List<Calendario> eventosDelDia) {
        eventosContainer.removeAllViews();

        if (eventosDelDia.isEmpty()) {
            Log.d("Calendario", "No hay eventos para mostrar.");

            TextView noEventos = new TextView(getActivity());
            noEventos.setText("No hay eventos para la fecha seleccionada.");
            noEventos.setTextSize(18f);
            noEventos.setTextColor(getResources().getColor(R.color.BlancoNormalGym));
            noEventos.setGravity(Gravity.CENTER);
            noEventos.setPadding(0, 30, 0, 30);
            eventosContainer.addView(noEventos);
        } else {
            Log.d("Calendario", "Mostrando " + eventosDelDia.size() + " eventos.");
            for (Calendario evento : eventosDelDia) {
                View eventoView = LayoutInflater.from(getActivity()).inflate(R.layout.item_evento, eventosContainer, false);

                TextView tituloEvento = eventoView.findViewById(R.id.titulo_evento);
                tituloEvento.setText("Evento: " + evento.getTitulo());

                TextView descripcionEvento = eventoView.findViewById(R.id.descripcion_evento);
                descripcionEvento.setText("Descripcion: " + evento.getDescripcion());

                TextView duracionEvento = eventoView.findViewById(R.id.duracion_evento);
                duracionEvento.setText("Duracion: " + evento.getDuracion());

                String urlImagen = evento.getUrl();
                ImageView iconoEvento = eventoView.findViewById(R.id.icono_categoria_evento);
                Glide.with(getActivity())
                        .load(urlImagen)
                        .placeholder(R.drawable.logo_sin_letras)
                        .error(R.drawable.logo_sin_letras)
                        .into(iconoEvento);

                eventosContainer.addView(eventoView);
            }
        }

        eventosContainer.setVisibility(View.VISIBLE);
    }

    private void marcarFechaSeleccionada(Calendar selectedDate) {
        // clonar la lista de eventos para no perder los eventos previos
        List<EventDay> eventosActualizados = new ArrayList<>(eventosMarcados);

        // añadir el evento del dia seleccionado con un icono diferente (rojo)
        eventosActualizados.add(new EventDay(selectedDate, R.drawable.dia_seleccionado_icono));

        // aplicar los eventos al calendario
        calendarView.setEvents(eventosActualizados);
    }



}
