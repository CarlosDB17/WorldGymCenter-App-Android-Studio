package com.example.worldgymcenterapp.model;

import com.google.gson.annotations.SerializedName;

public class Cliente {

    @SerializedName("dni")
    private String dni;  // dni unico del cliente

    @SerializedName("nombre")
    private String nombre;  // nombre del cliente

    @SerializedName("apellidos")
    private String apellidos;  // apellidos del cliente

    @SerializedName("email")
    private String email;  // correo electronico del cliente

    @SerializedName("contrasena")
    private String contrasena;  // contrasena del cliente

    @SerializedName("telefono")
    private String telefono;  // telefono de contacto del cliente

    @SerializedName("fechaNacimiento")
    private String fechaNacimiento;  // fecha de nacimiento del cliente

    @SerializedName("fechaCuota")
    private String fechaCuota;  // fecha de pago de la cuota del cliente

    // constructor principal para crear un cliente con todos los datos
    public Cliente(String dni, String nombre, String apellidos, String email, String contrasena, String telefono, String fechaNacimiento) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.email = email;
        this.contrasena = contrasena;
        this.telefono = telefono;
        this.fechaNacimiento = fechaNacimiento;
    }

    // constructor alternativo para cuando el cliente edita sus datos
    public Cliente(String dni, String nombre, String apellidos, String email, String telefono) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.email = email;
        this.telefono = telefono;
    }

    // getters y setters para acceder a los datos del cliente

    public String getDni() {
        return dni;  // devuelve el dni del cliente
    }

    public void setDni(String dni) {
        this.dni = dni;  // establece el dni del cliente
    }

    public String getNombre() {
        return nombre;  // devuelve el nombre del cliente
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;  // establece el nombre del cliente
    }

    public String getApellidos() {
        return apellidos;  // devuelve los apellidos del cliente
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;  // establece los apellidos del cliente
    }

    public String getEmail() {
        return email;  // devuelve el email del cliente
    }

    public void setEmail(String email) {
        this.email = email;  // establece el email del cliente
    }

    public String getContrasena() {
        return contrasena;  // devuelve la contrasena del cliente
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;  // establece la contrasena del cliente
    }

    public String getTelefono() {
        return telefono;  // devuelve el telefono del cliente
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;  // establece el telefono del cliente
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;  // devuelve la fecha de nacimiento del cliente
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;  // establece la fecha de nacimiento del cliente
    }

    public String getFechaCuota() {
        return fechaCuota;  // devuelve la fecha de cuota del cliente
    }

    public void setFechaCuota(String fechaCuota) {
        this.fechaCuota = fechaCuota;  // establece la fecha de cuota del cliente
    }
}
