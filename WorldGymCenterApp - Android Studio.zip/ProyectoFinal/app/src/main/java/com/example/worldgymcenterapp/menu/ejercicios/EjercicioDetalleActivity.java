package com.example.worldgymcenterapp.menu.ejercicios;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.model.Ejercicio;

public class EjercicioDetalleActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio_detalle);

        // obtener los detalles del ejercicio desde el Intent
        Ejercicio ejercicio = (Ejercicio) getIntent().getSerializableExtra("ejercicio");

        // mostrar los detalles en los TextViews correspondientes
        TextView nombre = findViewById(R.id.ejercicio_detalle_nombre);
        TextView descripcion = findViewById(R.id.ejercicio_detalle_descripcion);
        ImageView imageView = findViewById(R.id.ejercicio_detalle_imagen);

        nombre.setText(ejercicio.getNombre());
        descripcion.setText(ejercicio.getDescripcion());
        Glide.with(this).load(ejercicio.getImageUrl()).into(imageView); //uso Glide para cargar la imagen del ejercicio y mostrarla en el ImageView
    }
}
