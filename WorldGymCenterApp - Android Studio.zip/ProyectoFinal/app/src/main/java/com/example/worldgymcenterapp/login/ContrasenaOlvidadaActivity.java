package com.example.worldgymcenterapp.login;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.api.ApiService;
import com.example.worldgymcenterapp.metodos.correo.ComprobarDNI;
import com.example.worldgymcenterapp.api.RetrofitClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ContrasenaOlvidadaActivity extends AppCompatActivity {

    private EditText editCorreo, editDNI; // campos de entrada para correo y dni
    private Button btnRestablecer, btnVolverIniciar; // botones para restablecer la contrasena y volver a iniciar sesion
    private LinearLayout layoutFormulario, layoutMensajeConfirmacion; // contenedores para el formulario y el mensaje de confirmacion
    private TextView mensajeConfirmacion; // texto que muestra el mensaje de confirmacion
    private ProgressBar progressBar; // barra de progreso para mostrar la carga
    private ApiService apiService; // instancia de ApiService para las peticiones
    private final Handler handler = new Handler(); // handler para ejecutar tareas retrasadas

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contrasena_olvidada); // carga el layout de la actividad

        apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class); // crea una instancia de ApiService

        // inicializar vistas
        editCorreo = findViewById(R.id.editCorreo); // campo de texto para correo
        editDNI = findViewById(R.id.editDNI); // campo de texto para dni
        btnRestablecer = findViewById(R.id.botonRestablecer); // boton para restablecer la contrasena
        btnVolverIniciar = findViewById(R.id.iniciarButton); // boton para volver a iniciar sesion
        layoutFormulario = findViewById(R.id.layoutFormulario); // contenedor del formulario
        layoutMensajeConfirmacion = findViewById(R.id.layoutMensajeConfirmacion); // contenedor del mensaje de confirmacion
        mensajeConfirmacion = findViewById(R.id.mensajeConfirmacion); // texto del mensaje de confirmacion
        progressBar = findViewById(R.id.progressBar); // barra de progreso

        // ocultar mensaje de confirmacion y la barra de progreso al inicio
        layoutMensajeConfirmacion.setVisibility(View.GONE);
        progressBar.setVisibility(View.GONE);

        // al hacer clic en el boton de restablecer
        btnRestablecer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // aplicar animacion al boton
                animarBoton(v);

                // obtener los valores de los campos de texto
                String correo = editCorreo.getText().toString().trim();
                String dni = editDNI.getText().toString().trim();

                // verificar si el correo es valido
                if (!validarCorreo(correo)) {
                    Toast.makeText(ContrasenaOlvidadaActivity.this, "Correo no valido", Toast.LENGTH_SHORT).show();
                    return;
                }

                // verificar si el dni es valido
                if (!ComprobarDNI.validarDNI(dni)) {
                    Toast.makeText(ContrasenaOlvidadaActivity.this, "DNI no valido", Toast.LENGTH_SHORT).show();
                    return;
                }

                // si todo es valido, proceder a recuperar la contrasena
                recuperarContrasena(dni, correo);
            }
        });

        // al hacer clic en el boton de volver a iniciar sesion
        btnVolverIniciar.setOnClickListener(v -> finish()); // finalizar la actividad actual
    }

    // metodo para animar el boton cuando se hace clic
    private void animarBoton(View view) {
        // animacion de escala (bote) para el boton
        ObjectAnimator animator = ObjectAnimator.ofPropertyValuesHolder(
                view,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.1f, 1f), // aumenta un 10% y luego vuelve
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.1f, 1f)
        );
        animator.setDuration(200); // duracion de la animacion
        animator.start(); // ejecutar la animacion
    }

    // metodo para validar que el correo tenga el formato correcto
    private boolean validarCorreo(String correo) {
        return correo.contains("@") && correo.contains("."); // comprobar si contiene '@' y '.'
    }

    // metodo para recuperar la contrasena
    private void recuperarContrasena(String dni, String correo) {
        // ocultar el boton y mostrar la barra de progreso
        btnRestablecer.setVisibility(View.GONE);
        progressBar.setVisibility(View.VISIBLE);

        // despues de 2 segundos, ocultar la barra de progreso y mostrar el mensaje de confirmacion
        handler.postDelayed(() -> {
            progressBar.setVisibility(View.GONE);
            layoutFormulario.setVisibility(View.GONE);
            layoutMensajeConfirmacion.setVisibility(View.VISIBLE);
        }, 2000);

        // hacer la peticion a la API de manera asincrona
        Call<String> call = apiService.recuperarContrasena(dni, correo);
        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                if (response.isSuccessful() && response.body() != null) {
                    mensajeConfirmacion.setText(response.body()); // mostrar el mensaje de confirmacion en el TextView
                }
                // volver a mostrar el boton en caso de exito
                btnRestablecer.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                // mostrar un mensaje de error en caso de fallo
                Toast.makeText(ContrasenaOlvidadaActivity.this, "Error de conexion: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                // volver a mostrar el boton en caso de error
                btnRestablecer.setVisibility(View.VISIBLE);
            }
        });
    }

}
