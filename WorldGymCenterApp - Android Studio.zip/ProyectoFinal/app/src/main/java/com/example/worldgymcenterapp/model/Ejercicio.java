package com.example.worldgymcenterapp.model;

import java.io.Serializable;

public class Ejercicio implements Serializable {
    private int id;  // id unico para el ejercicio
    private String nombre;  // nombre del ejercicio
    private String descripcion;  // descripcion del ejercicio
    private String imageUrl;  // url de la imagen del ejercicio
    private String musculo;  // musculo que se trabaja con el ejercicio

    // constructor para crear un ejercicio con todos sus atributos
    public Ejercicio(int id, String nombre, String descripcion, String imageUrl, String musculo) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.imageUrl = imageUrl;
        this.musculo = musculo;
    }

    // metodo para obtener el id del ejercicio
    public int getId() {
        return id;
    }

    // metodo para obtener el nombre del ejercicio
    public String getNombre() {
        return nombre;
    }

    // metodo para obtener la descripcion del ejercicio
    public String getDescripcion() {
        return descripcion;
    }

    // metodo para obtener la url de la imagen del ejercicio
    public String getImageUrl() {
        return imageUrl;
    }

    // metodo para obtener el musculo que se trabaja con el ejercicio
    public String getMusculo() {
        return musculo;
    }
}
