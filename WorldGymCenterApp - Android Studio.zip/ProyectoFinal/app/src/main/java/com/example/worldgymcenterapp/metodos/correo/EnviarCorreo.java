package com.example.worldgymcenterapp.metodos.correo;

import android.os.AsyncTask;
import android.util.Log;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.util.Properties;

public class EnviarCorreo {

    // configuracion de servidor SMTP de gmail
    private static final String SMTP_HOST = "smtp.gmail.com"; // smtp de gmail
    private static final String SMTP_PORT = "587"; // puerto seguro para tls
    private static final String FROM_EMAIL = "worldgymcenterapp@gmail.com"; // correo de origen
    private static final String FROM_PASSWORD = "etzy naix dqrq vlhf"; // contrasena del correo de origen

    // metodo para enviar un correo sin imagen adjunta
    public static void enviarCorreoSinImagen(final String toEmail, final String subject, final String messageBody) {
        // se ejecuta en un hilo asyncrono para no bloquear el hilo principal
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                try {
                    // propiedades de la conexion SMTP
                    Properties properties = new Properties();
                    properties.put("mail.smtp.host", SMTP_HOST); // direccion del servidor SMTP
                    properties.put("mail.smtp.port", SMTP_PORT); // puerto de conexion
                    properties.put("mail.smtp.auth", "true"); // habilitar autenticacion
                    properties.put("mail.smtp.starttls.enable", "true"); // habilitar tls

                    // crear sesion de correo con autenticacion
                    Session session = Session.getInstance(properties, new javax.mail.Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            // proporcionar correo y contrasena para autenticar
                            return new PasswordAuthentication(FROM_EMAIL, FROM_PASSWORD);
                        }
                    });

                    // crear el mensaje a enviar
                    Message message = new MimeMessage(session);
                    message.setFrom(new InternetAddress(FROM_EMAIL)); // establecer el correo de origen
                    message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail)); // establecer el correo destino
                    message.setSubject(subject); // establecer el asunto del correo
                    message.setText(messageBody); // establecer el cuerpo del mensaje

                    // enviar el mensaje
                    Transport.send(message);

                    // log para indicar que el correo se envio exitosamente
                    Log.d("Correo", "Correo enviado con éxito");

                } catch (MessagingException e) {
                    // manejar excepciones
                    e.printStackTrace();
                    Log.e("Correo", "Error al enviar correo", e);
                }
                return null;
            }
        }.execute();
    }
}
