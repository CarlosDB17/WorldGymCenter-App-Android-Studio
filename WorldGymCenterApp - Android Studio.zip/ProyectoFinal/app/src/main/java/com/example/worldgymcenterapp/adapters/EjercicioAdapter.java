package com.example.worldgymcenterapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.api.ApiService;
import com.example.worldgymcenterapp.api.RetrofitClient;
import com.example.worldgymcenterapp.menu.ejercicios.EjercicioDetalleActivity;
import com.example.worldgymcenterapp.menu.ejercicios.ImageViewerActivity;
import com.example.worldgymcenterapp.metodos.correo.RecuperarDNI;
import com.example.worldgymcenterapp.model.Ejercicio;


import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EjercicioAdapter extends RecyclerView.Adapter<EjercicioAdapter.EjercicioViewHolder> {
    private List<Ejercicio> ejercicios;
    private Context context;
    private boolean mostrandoFavoritos;
    private String usuarioDni;

    // constructor para lista normal de ejercicios
    public EjercicioAdapter(List<Ejercicio> ejercicios) {
        this.ejercicios = ejercicios;
        this.mostrandoFavoritos = false;
    }

    // constructor para lista de favoritos
    public EjercicioAdapter(List<Ejercicio> ejercicios, boolean mostrandoFavoritos) {
        this.ejercicios = ejercicios;
        this.mostrandoFavoritos = mostrandoFavoritos;
    }

    @NonNull
    @Override
    public EjercicioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_ejercicio, parent, false);
        context = parent.getContext();
      //  usuarioDni = SharedPreferencesManager.getDni(context);
        usuarioDni = RecuperarDNI.obtenerDniSinContexto();

        return new EjercicioViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EjercicioViewHolder holder, int position) {
        Ejercicio ejercicio = ejercicios.get(position);
        holder.nombre.setText(ejercicio.getNombre());
        holder.descripcion.setText(ejercicio.getDescripcion());
        Glide.with(context).load(ejercicio.getImageUrl()).into(holder.imageView);

        //  ícono de favoritos
        configurarFavorito(holder, ejercicio);

        //  clic para detalles del ejercicio
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, EjercicioDetalleActivity.class);
            intent.putExtra("ejercicio", ejercicio);
            context.startActivity(intent);
        });

        //  clic en la imagen
        holder.imageView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ImageViewerActivity.class);
            intent.putExtra("imageUrl", ejercicio.getImageUrl());
            context.startActivity(intent);
        });
    }

    private void configurarFavorito(@NonNull EjercicioViewHolder holder, Ejercicio ejercicio) {
        //  muestro favoritos,corazon color rojo
        if (mostrandoFavoritos) {
            holder.iconoFavorito.setColorFilter(ContextCompat.getColor(context, R.color.rojoNormalGym));
        } else {
            // verifico si el ejercicio está en favoritos
            verificarEsFavorito(holder, ejercicio);
        }

        //  clic en el ícono de favoritos
        holder.iconoFavorito.setOnClickListener(v -> toggleFavorito(holder, ejercicio));
    }

    private void verificarEsFavorito(@NonNull EjercicioViewHolder holder, Ejercicio ejercicio) {
        ApiService apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        Call<Boolean> call = apiService.esFavorito(usuarioDni, ejercicio.getId());

        call.enqueue(new Callback<Boolean>() {
            @Override
            public void onResponse(Call<Boolean> call, Response<Boolean> response) {
                if (response.isSuccessful() && Boolean.TRUE.equals(response.body())) {
                    //  favorito
                    holder.iconoFavorito.setColorFilter(ContextCompat.getColor(context, R.color.rojoNormalGym));
                } else {
                    // no es favorito
                    holder.iconoFavorito.setColorFilter(ContextCompat.getColor(context, R.color.grisGym));
                }
            }

            @Override
            public void onFailure(Call<Boolean> call, Throwable t) {
                // en caso de error, dejarlo en gris
                holder.iconoFavorito.setColorFilter(ContextCompat.getColor(context, R.color.grisGym));
            }
        });
    }

    private void toggleFavorito(@NonNull EjercicioViewHolder holder, Ejercicio ejercicio) {
        ApiService apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        Call<Void> call;

        // verificar si ya está en favoritos y hacer la peticion correspondiente
        Call<Boolean> verificacionCall = apiService.esFavorito(usuarioDni, ejercicio.getId());

        verificacionCall.enqueue(new Callback<Boolean>() {
            @Override
            public void onResponse(Call<Boolean> call, Response<Boolean> response) {
                if (response.isSuccessful()) {
                    boolean esFavorito = Boolean.TRUE.equals(response.body());

                    if (esFavorito) {
                        // eliminar de favoritos
                        Call<Void> eliminarCall = apiService.eliminarFavorito(usuarioDni, ejercicio.getId());
                        eliminarCall.enqueue(new Callback<Void>() {
                            @Override
                            public void onResponse(Call<Void> call, Response<Void> response) {
                                if (response.isSuccessful()) {
                                    holder.iconoFavorito.setColorFilter(ContextCompat.getColor(context, R.color.grisGym));
                                    Toast.makeText(context, "Eliminado de favoritos", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onFailure(Call<Void> call, Throwable t) {
                                Toast.makeText(context, "Error al eliminar de favoritos", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {
                        // añadir a favoritos
                        Call<Void> agregarCall = apiService.agregarFavorito(usuarioDni, ejercicio.getId());
                        agregarCall.enqueue(new Callback<Void>() {
                            @Override
                            public void onResponse(Call<Void> call, Response<Void> response) {
                                if (response.isSuccessful()) {
                                    holder.iconoFavorito.setColorFilter(ContextCompat.getColor(context, R.color.rojoNormalGym));
                                    Toast.makeText(context, "Añadido a favoritos", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onFailure(Call<Void> call, Throwable t) {
                                Toast.makeText(context, "Error al añadir a favoritos", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }
            }

            @Override
            public void onFailure(Call<Boolean> call, Throwable t) {
                Toast.makeText(context, "Error al verificar favoritos", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return ejercicios.size();
    }

    public static class EjercicioViewHolder extends RecyclerView.ViewHolder {
        TextView nombre, descripcion;
        ImageView imageView, iconoFavorito;

        public EjercicioViewHolder(View itemView) {
            super(itemView);
            nombre = itemView.findViewById(R.id.nombre_ejercicio);
            descripcion = itemView.findViewById(R.id.descripcion_ejercicio);
            imageView = itemView.findViewById(R.id.imagen_ejercicio);
            iconoFavorito = itemView.findViewById(R.id.icono_favorito);
        }
    }
}