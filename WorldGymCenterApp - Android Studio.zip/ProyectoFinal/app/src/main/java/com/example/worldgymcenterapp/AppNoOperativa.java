package com.example.worldgymcenterapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class AppNoOperativa extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.no_operativo);

        Button btnReintentar = findViewById(R.id.btnReintentar);
        if (btnReintentar != null) {
            btnReintentar.setOnClickListener(v -> {
                // crear un intent nuevo en vez de reutilizar el existente
                Intent intent = new Intent(AppNoOperativa.this, MainActivity.class);
                startActivity(intent);
                finish();
            });
        }
    }
}
