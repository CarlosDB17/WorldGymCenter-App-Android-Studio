package com.example.worldgymcenterapp.menu.notificaciones;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.DialogFragment;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.example.worldgymcenterapp.R;

public class NotificacionDialogFragment extends DialogFragment {

    private static final String ARG_TITULO = "titulo";
    private static final String ARG_DESCRIPCION = "descripcion";
    private static final String ARG_FECHA = "fecha";
    private static final String ARG_URL_FOTO = "url_foto";

    private String titulo;
    private String descripcion;
    private String fecha;
    private String urlFoto;

    //  instancia del fragmento con los parametros
    public static NotificacionDialogFragment newInstance(String titulo, String descripcion, String fecha, String urlFoto) {
        NotificacionDialogFragment fragment = new NotificacionDialogFragment();
        Bundle args = new Bundle();
        args.putString(ARG_TITULO, titulo);
        args.putString(ARG_DESCRIPCION, descripcion);
        args.putString(ARG_FECHA, fecha);
        args.putString(ARG_URL_FOTO, urlFoto);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // layout del fragmento
        View view = inflater.inflate(R.layout.fragment_notificacion_detalles, container, false);

        // obtener los argumentos del fragmento
        if (getArguments() != null) {
            titulo = getArguments().getString(ARG_TITULO);
            descripcion = getArguments().getString(ARG_DESCRIPCION);
            fecha = getArguments().getString(ARG_FECHA);
            urlFoto = getArguments().getString(ARG_URL_FOTO);
        }

        TextView tvTitulo = view.findViewById(R.id.titulo_notificacion_detalle);
        TextView tvDescripcion = view.findViewById(R.id.descripcion_notificacion_detalle);
        TextView tvFecha = view.findViewById(R.id.fecha_notificacion_detalle);
        ImageView ivImagen = view.findViewById(R.id.imagen_notificacion_detalle);

        // configura los valores
        tvTitulo.setText(titulo);
        tvDescripcion.setText(descripcion);
        tvFecha.setText(fecha);

        // mostrar la imagen si hay URL
// mostrar la imagen si hay URL
        if (urlFoto != null && !urlFoto.isEmpty()) {
            ivImagen.setVisibility(View.VISIBLE);
            Glide.with(this)
                    .load(urlFoto)
                    .transition(DrawableTransitionOptions.withCrossFade())
                    .error(R.drawable.ic_notificacion) //si no hay muestro esto
                    .into(ivImagen);

            // aplicar filtro rojo para que las imagenes blancas se vean en fondo blanco
            ivImagen.setColorFilter(getResources().getColor(R.color.BlancoNormalGym), android.graphics.PorterDuff.Mode.SRC_ATOP);
        } else {
            ivImagen.setVisibility(View.GONE);
        }


        return view;
    }
}