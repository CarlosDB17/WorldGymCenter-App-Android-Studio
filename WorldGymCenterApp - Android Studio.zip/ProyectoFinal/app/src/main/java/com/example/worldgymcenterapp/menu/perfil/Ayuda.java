package com.example.worldgymcenterapp.menu.perfil;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.model.Pregunta;
import com.example.worldgymcenterapp.adapters.PreguntaAdapter;
import com.example.worldgymcenterapp.metodos.correo.EnviarCorreo;

import java.util.ArrayList;
import java.util.List;


import android.content.Intent;
import android.net.Uri;

public class Ayuda extends AppCompatActivity {

    private Button btnPreguntasFrecuentes;
    private Button btnFormularioContacto;
    private LinearLayout layoutAyudaPreguntas;
    private LinearLayout layoutFormularioContacto;

    private RecyclerView recyclerViewPreguntas;
    private PreguntaAdapter preguntaAdapter;
    private List<Pregunta> preguntaList;

    private Button botonEnviar;
    private EditText nombreEditText;
    private EditText correoEditText;
    private EditText mensajeEditText;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perfil_ayuda);


        ImageView imageViewMapa = findViewById(R.id.imageViewMapa);

        imageViewMapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // efecto de bote/pop-up al hacer click
                animarImagen(imageViewMapa);

                // abrir Google Maps después de la animación
                imageViewMapa.postDelayed(() -> {
                    String url = "https://maps.app.goo.gl/knLpwZoCmRkhYJtQ7";
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                }, 300); // espera 300ms para que se vea la animación antes de abrir Maps
            }
        });


        //inicializo mensaje, nombre y correo:
        nombreEditText = findViewById(R.id.nombreEditText);
        correoEditText = findViewById(R.id.correoEditText);
        mensajeEditText = findViewById(R.id.mensajeEditText);

        LinearLayout layoutMensajeEnviado = findViewById(R.id.layoutMensajeEnviado);

        Spinner spinnerAsunto = findViewById(R.id.spinnerAsunto);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
        R.array.asunto_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerAsunto.setAdapter(adapter);

// establecer que el primer ítem será no seleccionable.
        spinnerAsunto.setSelection(0); // para mostrar (seleccionar asunto)

// manejar el evento de selección
        spinnerAsunto.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                if (position == 0) {

                    //botonEnviar.setEnabled(false);
                    // Toast.makeText(getApplicationContext(), "Por favor, selecciona un asunto", Toast.LENGTH_SHORT).show();
                } else {

                    botonEnviar.setEnabled(true); //deja enviar si selecciono asunto
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                //botonEnviar.setEnabled(false);
            }
        });





        // inicializamos el RecyclerView
        recyclerViewPreguntas = findViewById(R.id.recycler_view_preguntas);
        recyclerViewPreguntas.setLayoutManager(new LinearLayoutManager(this));

//inicializo boton enviar
        botonEnviar = findViewById(R.id.enviarButton);


        // crear lista de preguntas
        preguntaList = new ArrayList<>();
        preguntaList.add(new Pregunta(getString(R.string.pregunta1), getString(R.string.respuesta1), R.drawable.flecha_correcta_abajo));
        preguntaList.add(new Pregunta(getString(R.string.pregunta2), getString(R.string.respuesta2), R.drawable.flecha_correcta_abajo));
        preguntaList.add(new Pregunta(getString(R.string.pregunta3), getString(R.string.respuesta3), R.drawable.flecha_correcta_abajo));
        preguntaList.add(new Pregunta(getString(R.string.pregunta4), getString(R.string.respuesta4), R.drawable.flecha_correcta_abajo));
        preguntaList.add(new Pregunta(getString(R.string.pregunta5), getString(R.string.respuesta5), R.drawable.flecha_correcta_abajo));
        preguntaList.add(new Pregunta(getString(R.string.pregunta6), getString(R.string.respuesta6), R.drawable.flecha_correcta_abajo));
        preguntaList.add(new Pregunta(getString(R.string.pregunta7), getString(R.string.respuesta7), R.drawable.flecha_correcta_abajo));


        preguntaAdapter = new PreguntaAdapter(this, preguntaList);
        recyclerViewPreguntas.setAdapter(preguntaAdapter);


        // inicializo los botones
        btnPreguntasFrecuentes = findViewById(R.id.btn_preguntas_frecuentes);
        btnFormularioContacto = findViewById(R.id.btn_formulario_contacto);

        // inicializos el layout de preguntas frecuentes
        layoutAyudaPreguntas = findViewById(R.id.layout_ayuda_preguntas);
        layoutFormularioContacto = findViewById(R.id.layout_formulario_contacto);

        // establezco el fondo de los botones al principio y el color del texto
        btnPreguntasFrecuentes.setBackgroundResource(R.drawable.boton_redondeado);
        btnPreguntasFrecuentes.setTextColor(getResources().getColor(R.color.BlancoNormalGym));

        btnFormularioContacto.setBackgroundResource(R.drawable.boton_redondeado_no_seleccionado);
        btnFormularioContacto.setTextColor(getResources().getColor(R.color.negroGym));

        // al principio el boton de formulario será más pequeño
        btnFormularioContacto.setScaleX(0.80f);
        btnFormularioContacto.setScaleY(0.80f);

        // al pulsar preguntas frecuentes
        btnPreguntasFrecuentes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layoutAyudaPreguntas.setVisibility(View.VISIBLE);
                layoutFormularioContacto.setVisibility(View.GONE);
                botonEnviar.setVisibility(View.GONE);
                layoutMensajeEnviado.setVisibility(View.GONE);
                btnFormularioContacto.setScaleX(0.80f);
                btnFormularioContacto.setScaleY(0.80f);
                btnPreguntasFrecuentes.setBackgroundResource(R.drawable.boton_redondeado);
                btnFormularioContacto.setBackgroundResource(R.drawable.boton_redondeado_no_seleccionado);
                btnPreguntasFrecuentes.setTextColor(getResources().getColor(R.color.BlancoNormalGym));
                btnFormularioContacto.setTextColor(getResources().getColor(R.color.negroGym));
                btnPreguntasFrecuentes.setScaleX(1f);
                btnPreguntasFrecuentes.setScaleY(1f);
            }
        });

        // al pulsar Formulario
        btnFormularioContacto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layoutAyudaPreguntas.setVisibility(View.GONE);
                layoutFormularioContacto.setVisibility(View.VISIBLE);
                botonEnviar.setVisibility(View.VISIBLE);
                btnPreguntasFrecuentes.setScaleX(0.80f);
                btnPreguntasFrecuentes.setScaleY(0.80f);
                btnFormularioContacto.setBackgroundResource(R.drawable.boton_redondeado);
                btnPreguntasFrecuentes.setBackgroundResource(R.drawable.boton_redondeado_no_seleccionado);
                btnFormularioContacto.setTextColor(getResources().getColor(R.color.BlancoNormalGym));
                btnPreguntasFrecuentes.setTextColor(getResources().getColor(R.color.negroGym));
                btnFormularioContacto.setScaleX(1f);
                btnFormularioContacto.setScaleY(1f);
                layoutMensajeEnviado.setVisibility(View.GONE);

            }
        });




        // el layout_titulo_perfil para retroceder a la ventana anterior
        LinearLayout layoutTituloPerfil = findViewById(R.id.layout_titulo);
        layoutTituloPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed(); // retrocede a la ventana anterior
            }
        });



        botonEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // obtener los textos de los EditText
                String nombre = nombreEditText.getText().toString().trim();
                String correo = correoEditText.getText().toString().trim();
                String mensaje = mensajeEditText.getText().toString().trim();
                String asunto = spinnerAsunto.getSelectedItem().toString();

                // obtener la selección del Spinner
                int selectedAsuntoPosition = spinnerAsunto.getSelectedItemPosition();

                // comprobar que el campo Nombre no este vacio
                if (nombre.isEmpty()) {
                    nombreEditText.setError("Este campo es obligatorio.");
                    return; // detener el envio si está vacio
                }

                // comprobar que el campo Correo no este vacio y tenga un formato válido
                if (correo.isEmpty()) {
                    correoEditText.setError("Este campo es obligatorio.");
                    return;
                } else if (!Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
                    correoEditText.setError("Por favor, introduce un correo válido.");
                    return; // detener el envío si el correo no es válido
                }

                // comprobar que el Spinner de Asunto tenga una opción válida seleccionada
                if (selectedAsuntoPosition == 0) {
                    Toast.makeText(Ayuda.this, "Por favor, selecciona un asunto", Toast.LENGTH_SHORT).show();
                    return; // detener el envío si no se seleccionó un asunto válido
                }

                // comprobar que el campo de Mensaje no esté vacío
                if (mensaje.isEmpty()) {
                    mensajeEditText.setError("Este campo es obligatorio.");
                    return; // detener el envío si el mensaje está vacío
                }

                // todo ok? se envia
                Toast.makeText(Ayuda.this, "Formulario Enviado.", Toast.LENGTH_SHORT).show();

                // Limpiar los campos de texto después de enviar el formulario
                nombreEditText.setText("");
                correoEditText.setText("");
                mensajeEditText.setText("");
                spinnerAsunto.setSelection(0);

                // ccultar el formulario y el botón de enviar
                layoutFormularioContacto.setVisibility(View.GONE);
                botonEnviar.setVisibility(View.GONE);

                // mostrar el mensaje de confirmación y la imagen
                layoutMensajeEnviado.setVisibility(View.VISIBLE);

                String datosCliente = "Cliente: " + nombre + " \n" + "Email del cliente: " + correo + " \n" + "Motivo: " + asunto + " \n" + "Mensaje: " + mensaje;

                //correo para el gym
                EnviarCorreo.enviarCorreoSinImagen("worldgymcenterapp@gmail.com", asunto, datosCliente);

                //correo para el usuario
                EnviarCorreo.enviarCorreoSinImagen(correo, "Gracias por ponerte en contacto", "¡Hola! Hemos recibido tu mensaje, intentaremos tardar lo mínimo posible en responderte.\n" +
                        "\n" +
                        "Un saludo, World Gym Center!");
            }
        });


    }

    // metodo para hacer que la imagen haga un efecto de bote/pop-up
    private void animarImagen(View view) {
        // aqui creamos la animación con ObjectAnimator , basicamente le decimos que cambie la escala de la imagen
        ObjectAnimator animator = ObjectAnimator.ofPropertyValuesHolder(
                view, // esto es la vista que vamos a animar, en este caso el imageview
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.05f, 1f), // escala en x: normal → 110% → normal otra vez
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.05f, 1f)  // escala en y: lo mismo, crece un poco y vuelve a su tamaño
        );
        // duración de la animación
        animator.setDuration(300);
        //  inicia la animación
        animator.start();
    }

}
