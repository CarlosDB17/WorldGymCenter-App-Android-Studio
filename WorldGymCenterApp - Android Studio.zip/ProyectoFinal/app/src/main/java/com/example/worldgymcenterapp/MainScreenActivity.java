package com.example.worldgymcenterapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.worldgymcenterapp.menu.calendario.CalendarFragment;
import com.example.worldgymcenterapp.menu.notificaciones.NotificacionesFragment;
import com.example.worldgymcenterapp.menu.perfil.ProfileFragment;
import com.example.worldgymcenterapp.menu.ejercicios.EjerciciosFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_screen);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);

        // cargar el fragmento por defecto (NotebookFragment)
        bottomNavigationView.setSelectedItemId(R.id.nav_calendar);  // pestaña inicial deseada

        // cargar el fragmento de Notebook por defecto
        loadFragment(new CalendarFragment());  // cambia a CalendarFragment, por defecto, es la q sale al iniciar

        // listener para cuando el usuario selecciona un ítem del menú
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            int id = item.getItemId();

            if (id == R.id.nav_calendar) {
                selectedFragment = new CalendarFragment();
            } else if (id == R.id.nav_workouts) {
                selectedFragment = new EjerciciosFragment();
            } else if (id == R.id.nav_notificacion) {
                selectedFragment = new NotificacionesFragment();
            } else if (id == R.id.nav_profile) {
                selectedFragment = new ProfileFragment();
            }

            // cargar el fragmento seleccionado
            if (selectedFragment != null) {
                loadFragment(selectedFragment);
            }
            return true;
        });
    }

    // metodo para cargar el fragmento
    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit();
    }
}
