package com.example.worldgymcenterapp.metodos.correo;

import android.util.Log;

import com.example.worldgymcenterapp.api.ApiService;
import com.example.worldgymcenterapp.api.RetrofitClient;
import com.example.worldgymcenterapp.model.Cliente;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ObtenerDatosUser {

    private static final String TAG = "ObtenerDatosUser"; // etiqueta para los logs

//obtiene el nombre completo del usuario.

    public static void obtenerNombreCompleto(String dni, ResultadoCallback callback) {
        obtenerCliente(dni, cliente -> {
            // obtiene el nombre y apellido del cliente y los concatena
            String nombreCompleto = cliente.getNombre() + " " + cliente.getApellidos();
            callback.onResultadoObtenido(nombreCompleto); // devuelve el resultado
        });
    }

    //obtiene el email del usuario.
    public static void obtenerEmail(String dni, ResultadoCallback callback) {
        obtenerCliente(dni, cliente -> callback.onResultadoObtenido(cliente.getEmail())); // devuelve el email
    }

    /**
     * obtiene el telefono del usuario.
     */
    public static void obtenerTelefono(String dni, ResultadoCallback callback) {
        obtenerCliente(dni, cliente -> callback.onResultadoObtenido(cliente.getTelefono())); // devuelve el telefono
    }

    /**
     * obtiene la fecha de cuota del usuario.
     */
    public static void obtenerFechaCuota(String dni, ResultadoCallback callback) {
        obtenerCliente(dni, cliente -> callback.onResultadoObtenido(cliente.getFechaCuota().toString())); // devuelve la fecha de cuota
    }

    // metodo generico para obtener datos del usuario sin repetir codigo.

    private static void obtenerCliente(String dni, ClienteCallback callback) {
        // instancia el servicio de api
        ApiService apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        // crea la llamada a la api para obtener el cliente por dni
        Call<Cliente> call = apiService.obtenerClientePorDni(dni);

        // ejecuta la llamada asincrona
        call.enqueue(new Callback<Cliente>() {
            @Override
            public void onResponse(Call<Cliente> call, Response<Cliente> response) {
                if (response.isSuccessful() && response.body() != null) {
                    // si la respuesta es exitosa y contiene datos, pasa el cliente al callback
                    callback.onClienteObtenido(response.body());
                } else {
                    // si hay un error en la respuesta, lo logea
                    Log.w(TAG, "Error al obtener los datos - Codigo: " + response.code());
                    callback.onClienteObtenido(null); // pasa null si no se obtienen datos
                }
            }

            @Override
            public void onFailure(Call<Cliente> call, Throwable t) {
                // si falla la solicitud, lo logea
                Log.e(TAG, "Error en la solicitud: " + t.getMessage(), t);
                callback.onClienteObtenido(null); // pasa null si ocurre un error
            }
        });
    }

    //interfaz para manejar la respuesta de obtenerCliente().
    private interface ClienteCallback {
        void onClienteObtenido(Cliente cliente); // metodo que pasa el cliente obtenido
    }

    //interfaz para devolver un string en las llamadas.
    public interface ResultadoCallback {
        void onResultadoObtenido(String resultado); // metodo que pasa el resultado obtenido
    }
}
