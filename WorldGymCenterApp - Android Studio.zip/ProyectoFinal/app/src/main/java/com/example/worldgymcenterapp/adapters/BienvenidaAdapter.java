package com.example.worldgymcenterapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.iniciandoapp.Bienvenida;
import com.example.worldgymcenterapp.login.Login;

import java.util.List;

public class BienvenidaAdapter extends RecyclerView.Adapter<BienvenidaAdapter.BienvenidaViewHolder> {

    private final Context context;
    private final List<Integer> backgrounds;
    private final List<Integer> icons;
    private final List<String> texts;

    public BienvenidaAdapter(Context context, List<Integer> backgrounds, List<Integer> icons, List<String> texts) {
        this.context = context;
        this.backgrounds = backgrounds;
        this.icons = icons;
        this.texts = texts;
    }

    @NonNull
    @Override
    public BienvenidaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.bienvenida_page, parent, false);
        return new BienvenidaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BienvenidaViewHolder holder, int position) {
        holder.itemView.setBackgroundResource(backgrounds.get(position));
        holder.icon.setImageResource(icons.get(position));
        holder.paragraph.setText(texts.get(position));

        if (position == backgrounds.size() - 1) {
            holder.buttonNext.setText("¡Comienza!");
            holder.buttonNext.setOnClickListener(v -> context.startActivity(new Intent(context, Login.class)));
        } else {
            holder.buttonNext.setText("Siguiente");
            holder.buttonNext.setOnClickListener(v -> ((Bienvenida) context).viewPager.setCurrentItem(position + 1));
        }


    }

    @Override
    public int getItemCount() {
        return backgrounds.size();
    }

    static class BienvenidaViewHolder extends RecyclerView.ViewHolder {
        ImageView icon;
        TextView paragraph;

        Button buttonNext;

        BienvenidaViewHolder(View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.icon);
            paragraph = itemView.findViewById(R.id.paragraph);
            buttonNext = itemView.findViewById(R.id.button_next);
        }
    }
}
