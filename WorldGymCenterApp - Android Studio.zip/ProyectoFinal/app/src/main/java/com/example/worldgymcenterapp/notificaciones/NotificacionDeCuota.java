package com.example.worldgymcenterapp.notificaciones;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class NotificacionDeCuota extends Worker {

    public NotificacionDeCuota(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        // aqui obtengo la fecha actual y la fecha del pago
        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("AjustesPrefs", Context.MODE_PRIVATE);
        long fechaPago = sharedPreferences.getLong("fecha_pago", 0);  // asegurate de tener la fecha de pago en SharedPreferences o base de datos

        if (fechaPago == 0) {
            return Result.failure(); // si no hay fecha de pago, fin
        }

        long currentTime = System.currentTimeMillis();
        long diasRestantes = (fechaPago - currentTime) / (1000 * 60 * 60 * 24); // convertimos de milisegundos a dias

        // enviar notificaciones segun los dias restantes
        if (diasRestantes == 5) {
            enviarNotificacion("Faltan 5 dias para tu pago", "Recuerda que tienes que pagar tu cuota en 5 dias.");
        } else if (diasRestantes == 0) {
            enviarNotificacion("Es dia de pagar tu cuota", "Hoy es el ultimo dia para pagar.");
        }

        // si quiero notificaciones todos los dias:
        if (diasRestantes > 0 && diasRestantes <= 5) {
            enviarNotificacion("Faltan " + diasRestantes + " dias para tu pago", "No olvides que tu pago esta cerca.");
        }

        return Result.success();
    }

    private void enviarNotificacion(String titulo, String mensaje) {
        // aqui defino como enviar la notificacion utilizando NotificacionHelper
        NotificacionHelper.enviarNotificacionPrueba(getApplicationContext(), titulo, mensaje);
    }
}
