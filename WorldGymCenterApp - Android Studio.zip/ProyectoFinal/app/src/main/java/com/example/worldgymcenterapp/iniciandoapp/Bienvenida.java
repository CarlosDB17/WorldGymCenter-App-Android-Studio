package com.example.worldgymcenterapp.iniciandoapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.login.Login;
import com.example.worldgymcenterapp.adapters.BienvenidaAdapter;

import java.util.ArrayList;
import java.util.List;

public class Bienvenida extends AppCompatActivity {

    public ViewPager2 viewPager;
    private List<Integer> backgrounds = new ArrayList<>(); // lista para almacenar los fondos de las diapositivas
    private List<Integer> icons = new ArrayList<>(); // lista para almacenar los iconos de las diapositivas
    private List<String> texts = new ArrayList<>(); // lista para almacenar los textos de las diapositivas
    private LinearLayout indicatorLayout; // layout que contendra los indicadores de progreso
    private TextView textSkip; // textview para el boton de "saltar"

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bienvenida); // establece el layout para esta actividad

        // asocia las vistas del layout con las variables
        viewPager = findViewById(R.id.viewPager);
        textSkip = findViewById(R.id.text_skip);
        indicatorLayout = findViewById(R.id.indicator_layout);

        setupData(); // metodo para cargar los datos (fondos, iconos y textos)
        setupViewPager(); // configura el viewpager2

        // accion del boton de "saltar", al hacer clic se redirige a la actividad de login
        textSkip.setOnClickListener(view -> startActivity(new Intent(Bienvenida.this, Login.class)));
    }

    private void setupData() {
        // cargar los fondos de las diapositivas
        backgrounds.add(R.drawable.fondo1);
        backgrounds.add(R.drawable.fondo2);
        backgrounds.add(R.drawable.fondo3);

        // cargar los iconos de las diapositivas (todos con el mismo icono en este caso)
        icons.add(R.drawable.logo_sin_letras);
        icons.add(R.drawable.logo_sin_letras);
        icons.add(R.drawable.logo_sin_letras);

        // cargar los textos de las diapositivas
        texts.add("Bienvenido a nuestro gimnasio!");
        texts.add("Entrena con los mejores");
        texts.add("¡Tu salud es nuestra prioridad!");
    }

    private void setupViewPager() {
        // configura el viewpager2 con un adaptador que toma los fondos, iconos y textos
        viewPager.setAdapter(new BienvenidaAdapter(this, backgrounds, icons, texts));

        // añade los indicadores de progreso (circulos) debajo del viewpager
        for (int i = 0; i < backgrounds.size(); i++) {
            View indicator = new View(this);
            indicator.setBackgroundResource(R.drawable.indicator_unselected); // indicador no seleccionado por defecto
            indicator.setLayoutParams(new LinearLayout.LayoutParams(20, 20)); // tamano de cada indicador
            indicatorLayout.addView(indicator); // anadir el indicador al layout
        }

        // establece el callback para detectar cuando el usuario cambia de diapositiva
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                // actualiza los indicadores de progreso segun la diapositiva seleccionada
                for (int i = 0; i < indicatorLayout.getChildCount(); i++) {
                    indicatorLayout.getChildAt(i).setBackgroundResource(
                            i == position ? R.drawable.indicator_selected : R.drawable.indicator_unselected);
                }
            }
        });
    }
}
