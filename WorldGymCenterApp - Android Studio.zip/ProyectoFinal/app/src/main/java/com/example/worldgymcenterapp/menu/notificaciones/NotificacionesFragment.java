package com.example.worldgymcenterapp.menu.notificaciones;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.adapters.NotificacionesAdapter;
import com.example.worldgymcenterapp.api.ApiService;
import com.example.worldgymcenterapp.api.RetrofitClient;
import com.example.worldgymcenterapp.model.Notificacion;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NotificacionesFragment extends Fragment {
    private static final String TAG = "NotificacionesFragment";

    private RecyclerView recyclerViewNotificaciones;
    private NotificacionesAdapter adapter;
    private List<Notificacion> listaNotificaciones;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_notificaciones, container, false);

        // Initialize list
        listaNotificaciones = new ArrayList<>();

        // Configura el RecyclerView
        recyclerViewNotificaciones = view.findViewById(R.id.recycler_view_notificaciones);
        recyclerViewNotificaciones.setLayoutManager(new LinearLayoutManager(getContext()));

        // Configura el adaptador con un listener para manejar clics
        adapter = new NotificacionesAdapter(listaNotificaciones, getContext(), notificacion -> {
            // Abrir el diálogo de detalles de notificación
            NotificacionDialogFragment dialogFragment = NotificacionDialogFragment.newInstance(
                    notificacion.getTitulo(),
                    notificacion.getDescripcion(),
                    new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(notificacion.getFecha()),
                    notificacion.getUrlFoto() // Pass the URL here
            );
            dialogFragment.show(getChildFragmentManager(), "notification_details");
        });
        recyclerViewNotificaciones.setAdapter(adapter);

        // Fetch notifications
        fetchNotificaciones();

        return view;
    }

    private void fetchNotificaciones() {
        Log.d(TAG, "Iniciando fetchNotificaciones()");

        ApiService apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        Call<List<Notificacion>> call = apiService.obtenerNotificacionesOrdenadas();

        Log.d(TAG, "Llamada API creada: " + call.request().url());

        call.enqueue(new Callback<List<Notificacion>>() {
            @Override
            public void onResponse(Call<List<Notificacion>> call, Response<List<Notificacion>> response) {
                Log.d(TAG, "onResponse llamado");

                if (response.isSuccessful()) {
                    Log.d(TAG, "Respuesta exitosa");

                    if (response.body() != null) {
                        Log.d(TAG, "Número de notificaciones recibidas: " + response.body().size());

                        listaNotificaciones = response.body();
                        adapter.setNotificaciones(listaNotificaciones);
                    } else {
                        Log.e(TAG, "Cuerpo de respuesta nulo");
                        Toast.makeText(getContext(), "No hay notificaciones", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Log error body for more details
                    try {
                        String errorBody = response.errorBody() != null ? response.errorBody().string() : "Error body es nulo";
                        Log.e(TAG, "Error en la respuesta. Código: " + response.code() +
                                ", Mensaje: " + response.message() +
                                ", Error Body: " + errorBody);

                        Toast.makeText(getContext(), "Error al cargar notificaciones: " + response.code(),
                                Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        Log.e(TAG, "Error al leer cuerpo de error", e);
                    }
                }
            }

            @Override
            public void onFailure(Call<List<Notificacion>> call, Throwable t) {
                // Log the full stack trace for comprehensive error information
                Log.e(TAG, "Fallo en la llamada", t);

                // More detailed error logging
                if (t instanceof IOException) {
                    Log.e(TAG, "Network error: " + t.getMessage());
                    Toast.makeText(getContext(), "Error de red: Verifique su conexión", Toast.LENGTH_SHORT).show();
                } else {
                    Log.e(TAG, "Conversion error: " + t.getMessage());
                    Toast.makeText(getContext(), "Error de conversión de datos", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}