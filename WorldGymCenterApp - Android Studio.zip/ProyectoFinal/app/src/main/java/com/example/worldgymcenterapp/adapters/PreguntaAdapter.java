package com.example.worldgymcenterapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.model.Pregunta;

import java.util.List;

public class PreguntaAdapter extends RecyclerView.Adapter<PreguntaAdapter.PreguntaViewHolder> {

    private List<Pregunta> preguntaList;
    private Context context;

    public PreguntaAdapter(Context context, List<Pregunta> preguntaList) {
        this.context = context;
        this.preguntaList = preguntaList;
    }

    @NonNull
    @Override
    public PreguntaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_pregunta, parent, false);
        return new PreguntaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PreguntaViewHolder holder, int position) {
        Pregunta pregunta = preguntaList.get(position);

        // texto de la pregunta y el ícono
        holder.iconoPregunta.setImageResource(pregunta.getIconoResId());
        holder.textoPregunta.setText(pregunta.getTextoPregunta());

        //  texto de la respuesta
        holder.textoRespuesta.setText(pregunta.getRespuestaTexto());

        // visibilidad de la respuesta
        holder.respuestaLayout.setVisibility(pregunta.isRespuestaVisible() ? View.VISIBLE : View.GONE);

        // rotación del ícono dependiendo de si la respuesta está visible
        holder.iconoPregunta.setRotation(pregunta.isRespuestaVisible() ? 90f : 0f);

        // visibilidad de la respuesta cuando se hace clic en el layout de la pregunta
        holder.layoutPregunta.setOnClickListener(v -> {
            pregunta.setRespuestaVisible(!pregunta.isRespuestaVisible());
            notifyItemChanged(position);
        });
    }

    @Override
    public int getItemCount() {
        return preguntaList.size();
    }

    public static class PreguntaViewHolder extends RecyclerView.ViewHolder {

        LinearLayout layoutPregunta;
        ImageView iconoPregunta;
        TextView textoPregunta;
        TextView textoRespuesta;
        LinearLayout respuestaLayout;

        public PreguntaViewHolder(@NonNull View itemView) {
            super(itemView);
            layoutPregunta = itemView.findViewById(R.id.layout_pregunta);
            iconoPregunta = itemView.findViewById(R.id.icono_pregunta);
            textoPregunta = itemView.findViewById(R.id.texto_pregunta);
            textoRespuesta = itemView.findViewById(R.id.texto_respuesta);
            respuestaLayout = itemView.findViewById(R.id.respuesta_layout);
        }
    }
}
