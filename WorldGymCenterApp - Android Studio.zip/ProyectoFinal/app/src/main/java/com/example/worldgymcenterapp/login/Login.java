package com.example.worldgymcenterapp.login;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.api.ApiService;
import com.example.worldgymcenterapp.api.RetrofitClient;
import com.example.worldgymcenterapp.iniciandoapp.RegisterActivity;
import com.example.worldgymcenterapp.MainScreenActivity;
import com.example.worldgymcenterapp.metodos.correo.RecuperarDNI;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Login extends AppCompatActivity {

    private static final int MIN_PASSWORD_LENGTH = 6; // longitud minima de la contrasena
    private SharedPreferences sharedPreferences; // para guardar preferencias del usuario
    private static final String PREF_NAME = "UserPrefs"; // nombre del archivo de preferencias
    private static final String KEY_DNI = "dni_encrypted"; // clave para guardar el dni cifrado

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this); // habilita la funcionalidad de borde a borde en la actividad
        setContentView(R.layout.login); // establece el layout de la actividad


        // aplicar margenes segun los insets del sistema
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom); // ajusta los margenes
            return insets;
        });

        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE); // inicializa shared preferences

        // conectar las vistas del layout con las variables
        EditText emailEditText = findViewById(R.id.emailEditText);
        EditText passwordEditText = findViewById(R.id.passwordEditText);
        Button loginButton = findViewById(R.id.loginButton);
        Button registerButton = findViewById(R.id.registerButton);
        TextView forgotPasswordTextView = findViewById(R.id.txtContrasenaOlvidada);

        // accion de "¿Olvidaste tu contrasena?"
        forgotPasswordTextView.setOnClickListener(v -> {
            startActivity(new Intent(Login.this, ContrasenaOlvidadaActivity.class)); // abre la actividad de contrasena olvidada
        });

        // accion para registrar usuario
        registerButton.setOnClickListener(v -> {
            startActivity(new Intent(Login.this, RegisterActivity.class)); // abre la actividad de registro
        });

        // accion de login
        loginButton.setOnClickListener(v -> {
            String email = emailEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (validateInputs(email, password)) { // valida los datos de entrada
                loginUser(email, password); // realiza el login si los datos son correctos
            }
        });
    }

    // valida los inputs de correo y contrasena
    private boolean validateInputs(String email, String password) {
        if (TextUtils.isEmpty(email) || !email.contains("@")) { // valida el correo
            Toast.makeText(this, "Por favor, introduce un correo válido", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (TextUtils.isEmpty(password)) { // valida la contrasena
            Toast.makeText(this, "No olvides escribir tu contrasena", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (password.length() < MIN_PASSWORD_LENGTH) { // valida la longitud de la contrasena
            Toast.makeText(this, "La contrasena debe tener al menos " + MIN_PASSWORD_LENGTH + " caracteres", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true; // si es valido devuelve true
    }

    // metodo para realizar el login
    private void loginUser(String email, String password) {
        ApiService apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class); // crea la instancia de la API
        Call<String> call = apiService.login(email, password); // hace la llamada para el login

        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                if (response.isSuccessful() && response.body() != null) { // si la respuesta es exitosa
                    String dni = response.body().trim(); // obtiene el dni del cuerpo de la respuesta
                    Log.d("Login", "DNI recibido: " + dni); // muestra el dni en el log
                    Toast.makeText(Login.this, "Sesion iniciada.", Toast.LENGTH_SHORT).show();

                    if (!dni.isEmpty()) { // si el dni no esta vacio
                        RecuperarDNI.guardarDni(Login.this, dni); // guarda el dni cifrado
                        startActivity(new Intent(Login.this, MainScreenActivity.class)); // abre la pantalla principal
                        finish(); // termina la actividad de login
                    } else {
                        Toast.makeText(Login.this, "Error: Usuario no encontrado", Toast.LENGTH_SHORT).show();
                    }
                } else { // si la respuesta no es exitosa
                    Toast.makeText(Login.this, "Error al iniciar sesion. Verifica tus credenciales", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                Toast.makeText(Login.this, "Error de conexion: " + t.getMessage(), Toast.LENGTH_SHORT).show(); // mensaje de error si la conexion falla
                Log.e("Login", "Error en la peticion", t); // log del error
            }
        });
    }

}
