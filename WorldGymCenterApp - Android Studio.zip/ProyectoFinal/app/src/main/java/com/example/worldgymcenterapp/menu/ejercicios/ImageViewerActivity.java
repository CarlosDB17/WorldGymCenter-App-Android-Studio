package com.example.worldgymcenterapp.menu.ejercicios;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.worldgymcenterapp.R;

public class ImageViewerActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_viewer);

        ImageView imageView = findViewById(R.id.full_image_view);

        // obtener la URL de la imagen desde el intent
        String imageUrl = getIntent().getStringExtra("imageUrl");

        // usar glide para cargar la imagen en tamaño completo
        Glide.with(this).load(imageUrl).into(imageView);
    }
}
