package com.example.worldgymcenterapp.notificaciones;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.work.Worker;
import androidx.work.WorkerParameters;
import com.example.worldgymcenterapp.notificaciones.NotificacionHelper;

public class NotificacionWorker extends Worker {

    public NotificacionWorker(Context context, WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @Override
    public Result doWork() {
        // aqui compruebo los sharedpreferences y decido si enviar o no la notificacion
        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("AjustesPrefs", Context.MODE_PRIVATE);
        boolean notificacionesActivadas = sharedPreferences.getBoolean("switch_notificaciones", true);

        if (notificacionesActivadas) {
            // si las notificaciones estan activadas, enviamos la notificacion
            NotificacionHelper.enviarNotificacionPrueba(getApplicationContext(), "Titulo de Prueba", "Este es un mensaje de prueba");
        }

        // devuelve que el trabajo fue completado
        return Result.success();
    }
}
