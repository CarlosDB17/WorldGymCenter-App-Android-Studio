package com.example.worldgymcenterapp.menu.perfil;

import static com.example.worldgymcenterapp.metodos.correo.RecuperarDNI.obtenerDni;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.api.ApiService;
import com.example.worldgymcenterapp.api.RetrofitClient;
import com.example.worldgymcenterapp.login.Login;
import com.example.worldgymcenterapp.metodos.correo.RecuperarDNI;
import com.example.worldgymcenterapp.model.Cliente;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AjustesCuentaEliminarCuenta extends AppCompatActivity {
    private static final String TAG = "AjustesCuentaEliminar"; // para logs
    private String clienteDni = "";
    private EditText editTextCorreo, editTextContrasena, editTextDni;
    private Button btnEliminarCuenta;
    private ApiService apiService;

    // añadimos las referencias al progressBar y scrollView
    private ProgressBar progressBar;
    private ScrollView scrollView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perfil_ajustes_cuenta_eliminar_cuenta);

        // obtener dni almacenado
        clienteDni = obtenerDni(this);
        Log.d(TAG, "dni almacenado en la app: " + clienteDni);

        // inicializar retrofit
        apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);

        // referencias a los elementos de la interfaz
        editTextCorreo = findViewById(R.id.correoEditText);
        editTextContrasena = findViewById(R.id.contrasenaEditText);
        editTextDni = findViewById(R.id.dniEditText);
        btnEliminarCuenta = findViewById(R.id.eliminarCuentaButton);

        // referencias al scrollView y progressBar
        progressBar = findViewById(R.id.progressBar);
        scrollView = findViewById(R.id.scroll1);

        // configurar boton de retroceso
        LinearLayout layoutTituloPerfil = findViewById(R.id.layout_titulo_ajustes);
        layoutTituloPerfil.setOnClickListener(v -> onBackPressed());

        // configurar boton de eliminacion
        btnEliminarCuenta.setOnClickListener(v -> verificarDatosYEliminar());
    }

    private void verificarDatosYEliminar() {
        String correo = editTextCorreo.getText().toString().trim();
        String contrasena = editTextContrasena.getText().toString().trim();
        String dniIngresado = editTextDni.getText().toString().trim();

        // verificar que los campos no esten vacios
        if (correo.isEmpty() || contrasena.isEmpty() || dniIngresado.isEmpty()) {
            Toast.makeText(this, "por favor, completa todos los campos.", Toast.LENGTH_SHORT).show();
            return;
        }

        // verificar que el dni ingresado coincide con el almacenado
        if (!dniIngresado.equals(clienteDni)) {
            Toast.makeText(this, "el dni ingresado no coincide con tu cuenta.", Toast.LENGTH_SHORT).show();
            return;
        }

        // mostrar progreso de verificacion de credenciales
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("verificando credenciales...");
        progressDialog.show();

        // verificar credenciales usando el endpoint de login
        apiService.login(correo, contrasena).enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                progressDialog.dismiss();

                if (response.isSuccessful() && response.body() != null) {
                    String dniObtenido = response.body();

                    // triple verificacion: dni del login = dni almacenado = dni ingresado
                    if (dniObtenido.equals(clienteDni) && dniObtenido.equals(dniIngresado)) {
                        // mostrar dialogo de confirmacion final
                        new AlertDialog.Builder(AjustesCuentaEliminarCuenta.this)
                                .setTitle("Confirmar eliminacion")
                                .setMessage("¿Estas seguro que deseas eliminar tu cuenta? esta accion no se puede deshacer.")
                                .setPositiveButton("Eliminar", (dialog, which) -> {
                                    // ocultar scrollView y mostrar progressBar antes de eliminar la cuenta
                                    scrollView.setVisibility(View.GONE);
                                    progressBar.setVisibility(View.VISIBLE);

                                    // llamamos a la funcion que elimina la cuenta
                                    eliminarCuenta(clienteDni);
                                })
                                .setNegativeButton("cancelar", null)
                                .show();
                    } else {
                        Toast.makeText(AjustesCuentaEliminarCuenta.this,
                                "las credenciales no corresponden a tu cuenta.",
                                Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(AjustesCuentaEliminarCuenta.this,
                            "usuario no encontrado o credenciales incorrectas.",
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                progressDialog.dismiss();

                Log.e(TAG, "error al conectar con el servidor: " + t.getMessage(), t);
                Toast.makeText(AjustesCuentaEliminarCuenta.this,
                        "error al verificar los datos.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void eliminarCuenta(String dni) {
        Log.d(TAG, "enviando solicitud para eliminar cuenta con dni: " + dni);

        apiService.eliminarCliente(dni).enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                Log.d(TAG, "respuesta recibida al eliminar cuenta - codigo http: " + response.code());

                if (response.isSuccessful() && response.body() != null) {
                    Log.d(TAG, "cuenta eliminada con exito. Respuesta del servidor: " + response.body());
                    Toast.makeText(AjustesCuentaEliminarCuenta.this, response.body(), Toast.LENGTH_SHORT).show();

                    // llamamos al metodo para borrar el dni de SharedPreferences
                    RecuperarDNI.borrarDni(AjustesCuentaEliminarCuenta.this);

                    // redirigir al usuario a la pantalla de login
                    Intent intent = new Intent(AjustesCuentaEliminarCuenta.this, Login.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // limpiar la pila de actividades
                    startActivity(intent);

                } else {
                    Log.e(TAG, "error al eliminar la cuenta. Codigo de error: " + response.code());
                    Toast.makeText(AjustesCuentaEliminarCuenta.this, "error al eliminar la cuenta.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                Log.e(TAG, "error al conectar con el servidor: " + t.getMessage(), t);
                Toast.makeText(AjustesCuentaEliminarCuenta.this, "error de conexion.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
