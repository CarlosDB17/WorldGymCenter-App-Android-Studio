package com.example.worldgymcenterapp.api;

import com.example.worldgymcenterapp.model.Notificacion;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class RetrofitClient {
    private static final String BASE_URL = "http://XX.XXX.XXX.XXX:8080/";
    private static Retrofit retrofit;

    // método para obtener la instancia de Retrofit
    public static Retrofit getRetrofitInstance() {
        if (retrofit == null) {
            // configurar OkHttpClient con tiempo de espera extendido
            OkHttpClient client = new OkHttpClient.Builder()
                    .connectTimeout(30, TimeUnit.SECONDS) // tiempo de espera para la conexión
                    .readTimeout(30, TimeUnit.SECONDS) // tiempo de espera para la lectura
                    .writeTimeout(30, TimeUnit.SECONDS) // tiempo de espera para la escritura
                    .build();

            // crear un Gson más tolerante para manejar fechas personalizadas
            Gson gson = new GsonBuilder()
                    .setLenient() // permitir configuraciones más flexibles para el análisis de datos
                    .registerTypeAdapter(Date.class, new Notificacion.CustomDateAdapter()) // adaptador para manejar fechas personalizadas
                    .create();

            // construir Retrofit con OkHttpClient y GsonConverter
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL) // establece la URL base para la API
                    .client(client)     // asigna el cliente OkHttp configurado
                    .addConverterFactory(ScalarsConverterFactory.create()) // permite el manejo de datos simples como cadenas
                    .addConverterFactory(GsonConverterFactory.create(gson)) // asigna el conversor Gson para los datos JSON
                    .build();
        }
        return retrofit; // devuelve la instancia de Retrofit
    }
}
