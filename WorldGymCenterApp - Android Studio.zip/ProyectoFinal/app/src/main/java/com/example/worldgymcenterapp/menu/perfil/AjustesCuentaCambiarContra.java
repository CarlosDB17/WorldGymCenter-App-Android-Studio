package com.example.worldgymcenterapp.menu.perfil;

import static com.example.worldgymcenterapp.metodos.correo.RecuperarDNI.obtenerDni;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.api.ApiService;
import com.example.worldgymcenterapp.api.RetrofitClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AjustesCuentaCambiarContra extends AppCompatActivity {

    private EditText contrasenaActualEditText, contrasena1EditText, contrasena2EditText;
    private Button guardarButton;
    private String clienteDni = "";
    private ProgressBar barraCargar;
    private LinearLayout layoutInicial;
    private LinearLayout layoutBoton;
    private LinearLayout layoutMensajeFinal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perfil_ajustes_cuenta_cambiar_contrasena);

        // inicializo
        contrasenaActualEditText = findViewById(R.id.contrasenaActualEditText);
        contrasena1EditText = findViewById(R.id.contrasena1EditText);
        contrasena2EditText = findViewById(R.id.contrasena2EditText);
        guardarButton = findViewById(R.id.guardarButton);
        barraCargar = findViewById(R.id.progressBar);
        layoutInicial = findViewById(R.id.ll_formulario);
        layoutBoton = findViewById(R.id.layout_boton);
        layoutMensajeFinal = findViewById(R.id.layout_cambio_correcto);

// boton para guardar cambios
        guardarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validarCampos()) { // solo si la validación es correcta se oculta el boton y se muestra la barra de carga
                    barraCargar.setVisibility(View.VISIBLE);
                    guardarButton.setVisibility(View.GONE);
                    cambiarContrasena(); // llamda a la API solo si pasa la validación
                }
            }
        });

        // configura el layout_titulo_ajustes para retroceder a la ventana anterior
        LinearLayout layoutTituloPerfil = findViewById(R.id.layout_titulo_ajustes);
        layoutTituloPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed(); // retrocede a la ventana anterior
            }
        });
    }

    private void validarYGuardar() {
        String contrasenaActual = contrasenaActualEditText.getText().toString().trim();
        String nuevaContrasena = contrasena1EditText.getText().toString().trim();
        String repetirContrasena = contrasena2EditText.getText().toString().trim();
        clienteDni = obtenerDni(this);

        if (clienteDni == null || clienteDni.isEmpty()) {
            Toast.makeText(this, "No se pudo obtener el DNI del usuario.", Toast.LENGTH_SHORT).show();
            ocultarCarga(); // Oculta el progress bar
            return;
        }

        if (contrasenaActual.isEmpty() || nuevaContrasena.isEmpty() || repetirContrasena.isEmpty()) {
            Toast.makeText(this, "Rellena todos los campos antes de guardar cambios.", Toast.LENGTH_SHORT).show();
            ocultarCarga();
            return;
        }

        if (nuevaContrasena.equals(contrasenaActual)) {
            Toast.makeText(this, "La nueva contraseña debe ser distinta a la actual.", Toast.LENGTH_SHORT).show();
            ocultarCarga();
            return;
        }

        if (nuevaContrasena.length() < 6 || nuevaContrasena.length() > 30) {
            Toast.makeText(this, "La contraseña debe tener entre 6 y 30 caracteres.", Toast.LENGTH_SHORT).show();
            ocultarCarga();
            return;
        }

        if (!nuevaContrasena.equals(repetirContrasena)) {
            Toast.makeText(this, "Las contraseñas no coinciden.", Toast.LENGTH_SHORT).show();
            ocultarCarga();
            return;
        }

        // llamar a la API
        ApiService apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        Call<String> call = apiService.cambiarContrasena(clienteDni, contrasenaActual, nuevaContrasena);

        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                ocultarCarga(); // oculta la barra de progreso cuando llega la respuesta

                if (response.isSuccessful()) {
                    layoutMensajeFinal.setVisibility(View.VISIBLE);
                    layoutInicial.setVisibility(View.GONE);
                    layoutBoton.setVisibility(View.GONE);
                    Toast.makeText(AjustesCuentaCambiarContra.this, "Contraseña cambiada correctamente.", Toast.LENGTH_SHORT).show();
                    finish(); // cierra la actividad tras cambiar la contraseña
                } else {
                    Toast.makeText(AjustesCuentaCambiarContra.this, "Error: contraseña incorrecta.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                ocultarCarga();
                Toast.makeText(AjustesCuentaCambiarContra.this, "Error de conexión con el servidor.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void ocultarCarga() {
        barraCargar.setVisibility(View.GONE);
        guardarButton.setVisibility(View.VISIBLE);
    }


    private void cambiarContrasena() {
        ApiService apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        Call<String> call = apiService.cambiarContrasena(clienteDni, contrasenaActualEditText.getText().toString().trim(), contrasena1EditText.getText().toString().trim());

        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                ocultarCarga();
                if (response.isSuccessful()) {
                    layoutMensajeFinal.setVisibility(View.VISIBLE);
                    layoutInicial.setVisibility(View.GONE);
                    layoutBoton.setVisibility(View.GONE);

                    Toast.makeText(AjustesCuentaCambiarContra.this, "Contraseña cambiada correctamente.", Toast.LENGTH_SHORT).show();
                    //finish();
                } else {
                    Toast.makeText(AjustesCuentaCambiarContra.this, "Error: contraseña incorrecta.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                ocultarCarga();
                Toast.makeText(AjustesCuentaCambiarContra.this, "Error de conexión con el servidor.", Toast.LENGTH_SHORT).show();
            }
        });

    }



    private boolean validarCampos() {
        String contrasenaActual = contrasenaActualEditText.getText().toString().trim();
        String nuevaContrasena = contrasena1EditText.getText().toString().trim();
        String repetirContrasena = contrasena2EditText.getText().toString().trim();
        clienteDni = obtenerDni(this);

        if (clienteDni == null || clienteDni.isEmpty()) {
            Toast.makeText(this, "No se pudo obtener el DNI del usuario.", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (contrasenaActual.isEmpty() || nuevaContrasena.isEmpty() || repetirContrasena.isEmpty()) {
            Toast.makeText(this, "Rellena todos los campos antes de guardar cambios.", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (nuevaContrasena.equals(contrasenaActual)) {
            Toast.makeText(this, "La nueva contraseña debe ser distinta a la actual.", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (nuevaContrasena.length() < 6 || nuevaContrasena.length() > 30) {
            Toast.makeText(this, "La contraseña debe tener entre 6 y 30 caracteres.", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!nuevaContrasena.equals(repetirContrasena)) {
            Toast.makeText(this, "Las contraseñas no coinciden.", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true; // si llega aquí la validación es correcta
    }


}
