package com.example.worldgymcenterapp.menu.perfil;

import static com.example.worldgymcenterapp.notificaciones.NotificacionHelper.enviarNotificacionPrueba;

import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.notificaciones.NotificacionDeCuota;

import java.util.concurrent.TimeUnit;

public class AjustesNotificaciones extends AppCompatActivity {

    private Switch switchNotificaciones;
    private Switch switchSilencio;
    private Switch switchNotificacionesImportantes;

    private AudioManager audioManager;
    private VideoView videoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perfil_ajustes_notificaciones);

        // inicializar AudioManager para controlar el volumen
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        // configura el layout_titulo_ajustes para retroceder a la ventana anterior
        LinearLayout layoutTituloAjustes = findViewById(R.id.layout_titulo_ajustes);
        layoutTituloAjustes.setOnClickListener(v -> onBackPressed());

        // inicializamos los switches
        switchNotificaciones = findViewById(R.id.switch_notificaciones);
        switchSilencio = findViewById(R.id.switch_silencio);
        switchNotificacionesImportantes = findViewById(R.id.switch_notificaciones_importantes);

        // inicializamos el VideoView
        videoView = findViewById(R.id.videoView);

        // cargar el video
        Uri videoUri = Uri.parse("android.resource://" + getPackageName() + "/raw/test_video3");
        videoView.setVideoURI(videoUri);
        videoView.setMediaController(new MediaController(this));
        videoView.start();

        // cargar el estado de los switches desde SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("AjustesPrefs", MODE_PRIVATE);
        switchNotificaciones.setChecked(sharedPreferences.getBoolean("switch_notificaciones", true));
        switchSilencio.setChecked(sharedPreferences.getBoolean("switch_silencio", false));
        switchNotificacionesImportantes.setChecked(sharedPreferences.getBoolean("switch_notificaciones_importantes", true));

        // simulacion de la fecha de pago (solo una vez al inicio)
        if (sharedPreferences.getLong("fecha_pago", 0) == 0) {
            long fechaPagoSimulada = System.currentTimeMillis() + (5 * 24 * 60 * 60 * 1000); // 5 dias mas desde el momento actual
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putLong("fecha_pago", fechaPagoSimulada);
            editor.apply();
        }

        // configurar el switch de notificaciones generales
        switchNotificaciones.setOnCheckedChangeListener((buttonView, isChecked) -> {
            String status = isChecked ? "activadas" : "desactivadas";
            Toast.makeText(AjustesNotificaciones.this, "Notificaciones generales " + status, Toast.LENGTH_SHORT).show();

            // guardar el estado en SharedPreferences
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("switch_notificaciones", isChecked);
            editor.apply();

            // cambiar el color del switch
            switchNotificaciones.setThumbTintList(ColorStateList.valueOf(ContextCompat.getColor(
                    AjustesNotificaciones.this, isChecked ? R.color.switch_on_color : R.color.switch_off_color)));
            switchNotificaciones.setTrackTintList(ColorStateList.valueOf(ContextCompat.getColor(
                    AjustesNotificaciones.this, isChecked ? R.color.switch_on_color : R.color.switch_off_color)));
        });

        // configurar el switch de notificaciones importantes
        switchNotificacionesImportantes.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // si esta activado, programamos la notificacion
                programarNotificacionDiaria();
                Toast.makeText(AjustesNotificaciones.this, "Notificaciones activadas", Toast.LENGTH_SHORT).show();
            } else {
                // si esta desactivado, cancelamos el trabajo programado
                WorkManager.getInstance(getApplicationContext()).cancelAllWorkByTag("cuota_notificacion");
                Toast.makeText(AjustesNotificaciones.this, "Notificaciones desactivadas", Toast.LENGTH_SHORT).show();
            }

            String status = isChecked ? "activadas" : "desactivadas";
            Toast.makeText(AjustesNotificaciones.this, "Notificaciones importantes " + status, Toast.LENGTH_SHORT).show();

            // guardar el estado en SharedPreferences
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("switch_notificaciones_importantes", isChecked);
            editor.apply();

            // cambiar el color del switch
            switchNotificacionesImportantes.setThumbTintList(ColorStateList.valueOf(ContextCompat.getColor(
                    AjustesNotificaciones.this, isChecked ? R.color.switch_on_color : R.color.switch_off_color)));
            switchNotificacionesImportantes.setTrackTintList(ColorStateList.valueOf(ContextCompat.getColor(
                    AjustesNotificaciones.this, isChecked ? R.color.switch_on_color : R.color.switch_off_color)));
        });


        // configurar el switch de silencio
        switchSilencio.setOnCheckedChangeListener((buttonView, isChecked) -> {
            String status = isChecked ? "activado" : "desactivado";
            Toast.makeText(AjustesNotificaciones.this, "Silencio de la app " + status, Toast.LENGTH_SHORT).show();

            // guardar el estado en SharedPreferences
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("switch_silencio", isChecked);
            editor.apply();

            // cambiar el color del switch y ajustar el volumen
            switchSilencio.setThumbTintList(ColorStateList.valueOf(ContextCompat.getColor(
                    AjustesNotificaciones.this, isChecked ? R.color.switch_on_color : R.color.switch_off_color)));
            switchSilencio.setTrackTintList(ColorStateList.valueOf(ContextCompat.getColor(
                    AjustesNotificaciones.this, isChecked ? R.color.switch_on_color : R.color.switch_off_color)));

            // silenciar o restaurar el volumen
            int volume = isChecked ? 0 : audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC) / 2;
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, volume, 0);
        });

        // boton para enviar notificacion de prueba
        Button botonNotificacion = findViewById(R.id.botonNotificacion);
        botonNotificacion.setOnClickListener(v -> {
            if (switchNotificaciones.isChecked()) {
                enviarNotificacionPrueba(AjustesNotificaciones.this,"NotiPrueba","MensajePrueba");
            } else {
                Toast.makeText(AjustesNotificaciones.this, "Notificaciones desactivadas", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // programar notificacion diaria
    private void programarNotificacionDiaria() {
        // cancelamos el trabajo anterior si ya existe uno programado con el tag "cuota_notificacion"
        WorkManager.getInstance(getApplicationContext()).cancelAllWorkByTag("cuota_notificacion");

        // ahora, programamos el nuevo trabajo con la configuracion correcta (ejecutar cada 12 horas)
        PeriodicWorkRequest cuotaNotificacionRequest = new PeriodicWorkRequest.Builder(
                NotificacionDeCuota.class, 12, TimeUnit.HOURS) // intervalo de 12 horas
                .setInitialDelay(1, TimeUnit.SECONDS)  // retraso inicial de 1 segundo para la primera ejecucion
                .addTag("cuota_notificacion")
                .build();
        WorkManager.getInstance(getApplicationContext()).enqueue(cuotaNotificacionRequest);
    }

}
