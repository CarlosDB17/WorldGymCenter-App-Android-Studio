package com.example.worldgymcenterapp.metodos.correo.foto;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.widget.ImageView;

public class GestorFotoPerfil {

    private static final String PREFS_NAME = "UserProfile";
    private static final String PROFILE_IMAGE_KEY = "profile_image_uri";

    // metodo para guardar la imagen en SharedPreferences
    public static void saveProfileImage(Context context, Uri imageUri) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PROFILE_IMAGE_KEY, imageUri.toString());
        editor.apply();
    }

    // metodo para cargar la imagen desde SharedPreferences
    public static Uri loadProfileImage(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String imageUriString = sharedPreferences.getString(PROFILE_IMAGE_KEY, null);
        return imageUriString != null ? Uri.parse(imageUriString) : null;
    }

    // metodo para aplicar la imagen al ImageView
    public static void applyProfileImageToView(Context context, ImageView imageView) {
        Uri imageUri = loadProfileImage(context);
        if (imageUri != null) {
            imageView.setImageURI(imageUri);
        }
    }
}
