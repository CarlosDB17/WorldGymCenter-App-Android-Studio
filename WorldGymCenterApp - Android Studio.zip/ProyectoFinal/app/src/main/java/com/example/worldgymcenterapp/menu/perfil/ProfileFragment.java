package com.example.worldgymcenterapp.menu.perfil;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.worldgymcenterapp.R;
import com.example.worldgymcenterapp.metodos.correo.ObtenerDatosUser;
import com.example.worldgymcenterapp.metodos.correo.RecuperarDNI;
import com.example.worldgymcenterapp.metodos.correo.foto.GestorFotoPerfil;

public class ProfileFragment extends Fragment {

    private ImageView profileImage;
    private TextView nombreArriba;
    private String clienteDni = "";


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // inflar el layout del fragmento
        View view = inflater.inflate(R.layout.fragment_perfil, container, false);

        nombreArriba = view.findViewById(R.id.textview_nombre);
        clienteDni = RecuperarDNI.obtenerDni(requireContext());

        // obtener y establecer el nombre del usuario
        ObtenerDatosUser.obtenerNombreCompleto(clienteDni, resultado -> {
            if (resultado != null && !resultado.isEmpty()) {
                nombreArriba.setText(resultado);
            } else {
                nombreArriba.setText("nombre no disponible");
            }
        });

        // obtener y aplicar la imagen de perfil guardada
        profileImage = view.findViewById(R.id.profile_image);
        GestorFotoPerfil.applyProfileImageToView(requireContext(), profileImage);

        // al hacer clic en la imagen del perfil, mostrar un mensaje
        profileImage.setOnClickListener(v ->
                Toast.makeText(requireContext(), "para cambiar la foto vaya al apartado datos personales", Toast.LENGTH_SHORT).show()
        );

        // configurar clics en opciones del perfil
        configurarOpcion(view, R.id.layout_opcion_clientes, ClientesAdmin.class, true);
        configurarOpcion(view, R.id.layout_opcion_perfil, DatosPersonales.class, false);
        configurarOpcion(view, R.id.layout_opcion_ajustes, Ajustes.class, false);
        configurarOpcion(view, R.id.layout_opcion_ayuda, Ayuda.class, false);
        configurarOpcion(view, R.id.layout_opcion_cerrar_sesion, CerrarSesion.class, false);

        return view;
    }

    // metodo para configurar la visibilidad de las opciones de perfil y redirigir
    private void configurarOpcion(View view, int layoutId, Class<?> destino, boolean esAdmin) {
        LinearLayout layout = view.findViewById(layoutId);
        if (!esAdmin) {
            // mostrar la opcion si no es admin
            layout.setVisibility(View.VISIBLE);
            layout.setOnClickListener(v -> startActivity(new Intent(getActivity(), destino)));
        } else {
            // ocultar la opcion si es admin
            layout.setVisibility(View.GONE);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // actualizar la imagen y el nombre cada vez que el fragmento vuelve a la vista
        GestorFotoPerfil.applyProfileImageToView(requireContext(), profileImage);
        ObtenerDatosUser.obtenerNombreCompleto(clienteDni, resultado -> {
            if (resultado != null && !resultado.isEmpty()) {
                nombreArriba.setText(resultado);
            }
        });
    }


}
